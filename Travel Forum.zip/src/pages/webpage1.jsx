import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import FrameComponent from "../components/frame-component";
import ForgotPasswordVariant from "../components/forgot-password-variant";

const Webpage1 = () => {
  const navigate = useNavigate();

  const onIPhone1415ProMaxClick = useCallback(() => {
    navigate("/webpage");
  }, [navigate]);

  return (
    <div className="w-full relative flex flex-row items-start justify-start leading-[normal] tracking-[normal]">
      <section
        className="flex-1 [background:linear-gradient(195deg,_#bd721a,_#d5b43f_59.17%,_#c89039)] overflow-hidden flex flex-col items-start justify-start pt-[132px] px-[318px] pb-[157px] box-border gap-[140px] max-w-full cursor-pointer text-left text-5xl text-saddlebrown-400 font-poppins mq450:gap-[17px] mq450:pl-5 mq450:pr-5 mq450:box-border mq725:gap-[35px] mq725:pl-[79px] mq725:pr-[79px] mq725:box-border mq975:pt-[86px] mq975:pb-[102px] mq975:box-border mq1050:gap-[70px] mq1050:pl-[159px] mq1050:pr-[159px] mq1050:box-border"
        onClick={onIPhone1415ProMaxClick}
      >
        <img
          className="w-[337px] relative max-h-full hidden max-w-full"
          alt=""
          src="/rectangle-2.svg"
        />
        <div className="w-[239px] relative leading-[16px] hidden items-center h-[33px] shrink-0 mq450:text-lgi mq450:leading-[13px]">
          PASSWORD
        </div>
        <div className="w-[361px] h-0 relative text-xl leading-[16px] font-extrabold text-saddlebrown-100 hidden items-center max-w-full mq450:text-base mq450:leading-[13px]">
          Create an account
        </div>
        <div className="w-[402px] flex flex-col items-start justify-start gap-[37px] max-w-full mq450:gap-[18px]">
          <div className="w-[287px] flex flex-row items-start justify-start py-0 px-[11px] box-border">
            <div className="flex-1 flex flex-row items-start justify-between gap-[20px] mq450:flex-wrap">
              <div className="flex flex-col items-start justify-start pt-1 px-0 pb-0">
                <img
                  className="w-[42px] h-[26.8px] relative z-[1]"
                  loading="lazy"
                  alt=""
                  src="/vector.svg"
                />
              </div>
              <div className="flex flex-col items-start justify-start pt-1 px-0 pb-0">
                <img
                  className="w-[37px] h-[29.4px] relative z-[1]"
                  loading="lazy"
                  alt=""
                  src="/vector-1.svg"
                />
              </div>
              <div className="flex flex-row items-start justify-start relative">
                <div className="h-[49px] w-[306px] absolute !m-[0] top-[calc(50%_-_24.5px)] left-[-238px] rounded-21xl bg-madpackerscom" />
                <img
                  className="h-[39px] w-[53px] relative overflow-hidden shrink-0 z-[1]"
                  loading="lazy"
                  alt=""
                  src="/mdilinkedin.svg"
                />
              </div>
            </div>
          </div>
          <FrameComponent />
        </div>
        <div className="w-[33px] h-[33px] relative overflow-hidden shrink-0 hidden" />
        <div className="w-[371px] flex flex-row items-start justify-start py-0 px-[5px] box-border max-w-full text-13xl text-lightgray">
          <div className="flex-1 flex flex-col items-start justify-start gap-[40px] max-w-full mq450:gap-[20px]">
            <div className="self-stretch flex flex-row items-start justify-end py-0 px-11 mq450:pl-5 mq450:pr-5 mq450:box-border">
              <div className="w-[249px] flex flex-row items-start justify-start relative">
                <div className="h-[74px] w-[286px] absolute !m-[0] bottom-[-40px] left-[-84px] rounded-71xl [background:linear-gradient(90deg,_#ee801b,_#ee871a_52.5%,_#efd715_99.99%,_#f0e715)]" />
                <div className="flex-1 relative leading-[16px] font-extrabold whitespace-nowrap z-[1] mq450:text-lgi mq450:leading-[10px] mq975:text-7xl mq975:leading-[13px]">
                  Sign Up
                </div>
              </div>
            </div>
            <ForgotPasswordVariant
              forgotPassword="Already have an account?"
              propPosition="unset"
              propTop="unset"
              propLeft="unset"
              propWidth="unset"
              propHeight="unset"
              propAlignSelf="stretch"
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Webpage1;
