import { useCallback } from "react";
import FrameComponent from "../components/frame-component";
import LoginName from "../components/login-name";
import ForgotPasswordDefault from "../components/forgot-password-default";
import ForgotPasswordVariant from "../components/forgot-password-variant";
import { useNavigate } from "react-router-dom";

const Webpage = () => {
  const navigate = useNavigate();

  const onCreateAnAccountClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className="relative [background:linear-gradient(195deg,_#bd721a,_#d5b43f_59.17%,_#c89039)] w-full overflow-hidden flex flex-col items-end justify-start pt-[127px] px-[191px] pb-[79px] box-border gap-[41px] leading-[normal] tracking-[normal] text-left text-5xl text-saddlebrown-400 font-poppins mq450:pl-5 mq450:pr-5 mq450:box-border mq750:gap-[20px] mq750:pl-[95px] mq750:pr-[95px] mq750:box-border">
      <img
        className="w-[337px] relative max-h-full hidden max-w-full"
        alt=""
        src="/rectangle-2.svg"
      />
      <div className="w-[239px] h-0 relative leading-[16px] hidden items-center mq450:text-lgi mq450:leading-[13px]">
        PASSWORD
      </div>
      <div className="w-[361px] h-0 relative text-xl leading-[16px] font-extrabold text-saddlebrown-100 hidden items-center max-w-full mq450:text-base mq450:leading-[13px]">
        Create an account
      </div>
      <div className="w-10 h-[39px] relative overflow-hidden shrink-0 hidden" />
      <FrameComponent />
      <footer className="w-[400px] flex flex-col items-start justify-start max-w-full text-left text-xl text-saddlebrown-200 font-poppins">
        <LoginName />
        <div className="self-stretch flex flex-row items-start justify-start py-0 pr-0 pl-[39px] box-border max-w-full">
          <div className="flex-1 flex flex-col items-start justify-start max-w-full">
            <div className="self-stretch h-[60px] relative max-w-full">
              <ForgotPasswordDefault />
              <ForgotPasswordVariant forgotPassword="Forgot Password?" />
            </div>
            <div className="self-stretch h-[60px] relative max-w-full mt-[-19px]">
              <ForgotPasswordVariant
                forgotPassword="Create an account"
                propPosition="absolute"
                propTop="0px"
                propLeft="0px"
                propWidth="100%"
                propHeight="100%"
                propAlignSelf="unset"
              />
              <div
                className="absolute top-[0px] left-[0px] [text-decoration:underline] leading-[16px] font-extrabold flex items-center w-full h-full cursor-pointer z-[3] mq450:text-base mq450:leading-[13px]"
                onClick={onCreateAnAccountClick}
              >
                Create an account
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Webpage;
