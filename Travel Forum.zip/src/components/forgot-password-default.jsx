import PropTypes from "prop-types";

const ForgotPasswordDefault = ({ className = "" }) => {
  return (
    <div
      className={`absolute top-[0px] left-[0px] w-full flex flex-row items-start justify-start pt-0 px-0 pb-11 box-border max-w-full h-full text-left text-xl text-saddlebrown-200 font-poppins ${className}`}
    >
      <div className="flex-1 relative leading-[16px] font-extrabold inline-block max-w-full mq450:text-base mq450:leading-[13px]">
        Forgot Password?
      </div>
    </div>
  );
};

ForgotPasswordDefault.propTypes = {
  className: PropTypes.string,
};

export default ForgotPasswordDefault;
