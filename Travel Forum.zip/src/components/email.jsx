import "antd/dist/antd.min.css";
import { Select } from "antd";
import PropTypes from "prop-types";

const Email = ({ className = "" }) => {
  return (
    <Select
      className={`self-stretch font-poppins text-5xl text-saddlebrown-400 mq450:gap-[24px] mq750:flex-wrap ${className}`}
      virtual={false}
      showArrow={false}
    >{` `}</Select>
  );
};

Email.propTypes = {
  className: PropTypes.string,
};

export default Email;
