import { useMemo } from "react";
import PropTypes from "prop-types";

const LoginName = ({ className = "", rectangle3AlignItems }) => {
  const rectangleIconStyle = useMemo(() => {
    return {
      alignItems: rectangle3AlignItems,
    };
  }, [rectangle3AlignItems]);

  return (
    <div
      className={`w-[286px] h-[74px] rounded-71xl [background:linear-gradient(90deg,_#ee801b,_#ee871a_52.5%,_#efd715_99.99%,_#f0e715)] flex flex-row items-start justify-start py-[18px] px-[93px] box-border text-left text-13xl text-lightgray font-poppins mq450:pl-5 mq450:pr-5 mq450:box-border ${className}`}
    >
      <img
        className="h-[74px] w-[286px] relative rounded-71xl hidden"
        alt=""
        src="/rectangle-3.svg"
        style={rectangleIconStyle}
      />
      <div className="relative leading-[16px] font-extrabold inline-block min-w-[90px] z-[1] mq450:text-lgi mq450:leading-[10px] mq1025:text-7xl mq1025:leading-[13px]">
        Login
      </div>
    </div>
  );
};

LoginName.propTypes = {
  className: PropTypes.string,

  /** Style props */
  rectangle3AlignItems: PropTypes.any,
};

export default LoginName;
