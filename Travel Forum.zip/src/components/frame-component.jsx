import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";

const FrameComponent = ({ className = "" }) => {
  const navigate = useNavigate();

  const onImageClick = useCallback(() => {
    navigate("/webpage");
  }, [navigate]);

  return (
    <div
      className={`self-stretch shadow-[0px_45px_50px_rgba(0,_0,_0,_0.25)] flex flex-col items-start justify-start pt-2 pb-[36.5px] pr-5 pl-[46px] relative gap-[90px] text-left text-5xl text-saddlebrown-400 font-poppins mq450:gap-[45px] mq450:pl-5 mq450:box-border ${className}`}
    >
      <div className="w-[501px] h-[389px] absolute !m-[0] bottom-[-87px] left-[-112px] shadow-[23.6px_-23.6px_23.63px_rgba(165,_165,_165,_0.1)_inset,_-23.6px_23.6px_23.63px_rgba(255,_255,_255,_0.1)_inset] [backdrop-filter:blur(47.27px)] rounded-36xl bg-whitesmoke-200" />
      <div className="w-[416px] h-[391px] absolute !m-[0] right-[-403px] bottom-[-89px] rounded-31xl cursor-pointer flex items-center justify-center z-[1]">
        <img
          className="w-full h-full cursor-pointer object-contain absolute left-[0px] top-[45px] [transform:scale(1.256)]"
          loading="lazy"
          alt=""
          src="/image-1@2x.png"
          onClick={onImageClick}
        />
      </div>
      <h2 className="m-0 w-[295px] relative text-21xl leading-[16px] font-extrabold font-inherit text-saddlebrown-300 flex items-center z-[1] mq450:text-5xl mq450:leading-[10px] mq975:text-13xl mq975:leading-[13px]">
        Sign Up
      </h2>
      <div className="w-[276px] flex flex-row items-start justify-start relative">
        <div className="w-[239px] absolute !m-[0] bottom-[1.5px] left-[-100px] leading-[16px] flex items-center z-[1] mq450:text-lgi mq450:leading-[13px]">
          Password
        </div>
        <div className="h-px w-[373px] absolute !m-[0] top-[49px] left-[-100px] box-border z-[1] border-t-[1px] border-solid border-black" />
        <div className="w-[239px] absolute !m-[0] bottom-[61.5px] left-[-100px] leading-[16px] flex items-center z-[1] mq450:text-lgi mq450:leading-[13px]">
          EMAIL
        </div>
        <div className="flex-1 flex flex-row items-start justify-end">
          <div className="flex flex-col items-start justify-start gap-[49px]">
            <img
              className="w-6 h-6 relative overflow-hidden shrink-0 z-[1]"
              loading="lazy"
              alt=""
              src="/materialsymbolsperson.svg"
            />
            <div className="flex flex-col items-end justify-start gap-[40.5px]">
              <img
                className="w-[20.3px] h-[12.5px] relative z-[1]"
                alt=""
                src="/hidden-icon.svg"
              />
              <img
                className="w-[14.8px] h-[17.5px] relative z-[1]"
                loading="lazy"
                alt=""
                src="/vector-3.svg"
              />
            </div>
          </div>
        </div>
      </div>
      <div className="w-[373px] h-px absolute !m-[0] bottom-[20px] left-[-54px] box-border z-[2] border-t-[1px] border-solid border-black" />
      <div className="w-[373px] h-px absolute !m-[0] bottom-[71px] left-[-54px] box-border z-[2] border-t-[1px] border-solid border-black" />
      <div className="absolute !m-[0] top-[118px] left-[-54px] leading-[16px] inline-block min-w-[124px] z-[2] mq450:text-lgi mq450:leading-[13px]">
        Username
      </div>
    </div>
  );
};

FrameComponent.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent;
