/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        saddlebrown: {
          "100": "#834a15",
          "200": "#834c0c",
          "300": "#704a10",
          "400": "#62360c",
          "500": "rgba(98, 54, 12, 0)",
        },
        lightgray: "#d5ccbd",
        black: "#000",
        whitesmoke: {
          "100": "rgba(250, 248, 248, 0)",
          "200": "rgba(250, 248, 248, 0.46)",
        },
        madpackerscom: "#cd9529",
        gray: "rgba(0, 0, 0, 0)",
      },
      spacing: {},
      fontFamily: {
        poppins: "Poppins",
      },
      borderRadius: {
        "71xl": "90px",
        "31xl": "50px",
        "36xl": "55px",
        "21xl": "40px",
      },
    },
    fontSize: {
      xl: "20px",
      base: "16px",
      "13xl": "32px",
      lgi: "19px",
      "7xl": "26px",
      "5xl": "24px",
      "21xl": "40px",
      inherit: "inherit",
    },
    screens: {
      mq1100: {
        raw: "screen and (max-width: 1100px)",
      },
      mq1050: {
        raw: "screen and (max-width: 1050px)",
      },
      mq1025: {
        raw: "screen and (max-width: 1025px)",
      },
      mq975: {
        raw: "screen and (max-width: 975px)",
      },
      mq750: {
        raw: "screen and (max-width: 750px)",
      },
      mq725: {
        raw: "screen and (max-width: 725px)",
      },
      mq450: {
        raw: "screen and (max-width: 450px)",
      },
    },
  },
  corePlugins: {
    preflight: false,
  },
};
