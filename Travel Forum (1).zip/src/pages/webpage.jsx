import FrameComponent from "../components/frame-component1";
import Footer from "../components/footer";

const Webpage = () => {
  return (
    <div className="relative [background:linear-gradient(195deg,_#bd721a,_#d5b43f_59.17%,_#c89039)] w-full overflow-hidden flex flex-col items-end justify-start pt-[127px] px-[191px] pb-[104px] box-border gap-[41px] leading-[normal] tracking-[normal] text-left text-5xl text-saddlebrown-400 font-poppins mq450:pl-5 mq450:pr-5 mq450:box-border mq750:gap-[20px] mq750:pl-[95px] mq750:pr-[95px] mq750:box-border">
      <img
        className="w-[337px] relative max-h-full hidden max-w-full"
        alt=""
        src="/rectangle-2.svg"
      />
      <div className="w-[239px] h-0 relative leading-[16px] hidden items-center mq450:text-lgi mq450:leading-[13px]">
        PASSWORD
      </div>
      <div className="w-[361px] h-0 relative text-xl leading-[16px] font-extrabold text-saddlebrown-100 hidden items-center max-w-full mq450:text-base mq450:leading-[13px]">
        Create an account
      </div>
      <div className="w-10 h-[39px] relative overflow-hidden shrink-0 hidden" />
      <FrameComponent />
      <Footer />
    </div>
  );
};

export default Webpage;
