import { useMemo } from "react";
import PropTypes from "prop-types";

const ForgotPasswordVariant = ({
  className = "",
  forgotPassword,
  propPosition,
  propTop,
  propLeft,
  propWidth,
  propHeight,
  propAlignSelf,
}) => {
  const forgotPasswordVariant2Style = useMemo(() => {
    return {
      position: propPosition,
      top: propTop,
      left: propLeft,
      width: propWidth,
      height: propHeight,
      alignSelf: propAlignSelf,
    };
  }, [propPosition, propTop, propLeft, propWidth, propHeight, propAlignSelf]);

  return (
    <div
      className={`absolute top-[0px] left-[0px] w-full flex flex-row items-start justify-start pt-0 px-0 pb-11 box-border max-w-full h-full z-[1] text-left text-xl text-saddlebrown-200 font-poppins ${className}`}
      style={forgotPasswordVariant2Style}
    >
      <div className="flex-1 relative [text-decoration:underline] leading-[16px] font-extrabold inline-block max-w-full mq450:text-base mq450:leading-[13px]">
        {forgotPassword}
      </div>
    </div>
  );
};

ForgotPasswordVariant.propTypes = {
  className: PropTypes.string,
  forgotPassword: PropTypes.string,

  /** Style props */
  propPosition: PropTypes.any,
  propTop: PropTypes.any,
  propLeft: PropTypes.any,
  propWidth: PropTypes.any,
  propHeight: PropTypes.any,
  propAlignSelf: PropTypes.any,
};

export default ForgotPasswordVariant;
