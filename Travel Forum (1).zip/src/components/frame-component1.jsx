import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";

const FrameComponent = ({ className = "" }) => {
  const navigate = useNavigate();

  const onImageClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <section
      className={`flex flex-row items-start justify-start py-0 px-[38px] box-border max-w-full text-left text-21xl text-saddlebrown-300 font-poppins ${className}`}
    >
      <div className="w-[812px] flex flex-row items-end justify-start [row-gap:20px] max-w-full mq1100:flex-wrap">
        <div className="h-[353px] w-[377px] relative rounded-31xl max-w-full cursor-pointer flex items-center justify-center">
          <img
            className="h-full w-full cursor-pointer object-contain absolute left-[0px] top-[45px] [transform:scale(1.283)] mq1100:flex-1"
            loading="lazy"
            alt=""
            src="/image-11@2x.png"
            onClick={onImageClick}
          />
        </div>
        <div className="h-[410px] flex-1 relative min-w-[283px] max-w-full mq750:h-auto mq750:min-h-[410]">
          <div className="absolute top-[39px] left-[0px] shadow-[0px_45px_50px_rgba(0,_0,_0,_0.25)] w-full h-[371px] max-w-full z-[1] mq750:h-auto mq750:min-h-[371]">
            <div className="absolute w-full top-[18px] right-[0px] left-[0px] shadow-[23.6px_-23.6px_23.63px_rgba(165,_165,_165,_0.1)_inset,_-23.6px_23.6px_23.63px_rgba(255,_255,_255,_0.1)_inset] [backdrop-filter:blur(47.27px)] rounded-36xl bg-whitesmoke-200 h-[353px]" />
            <div className="absolute w-full top-[0px] right-[0px] left-[0px] shadow-[0px_45px_50px_rgba(0,_0,_0,_0.25)] flex flex-col items-start justify-start pt-[47px] pb-[69px] pr-1.5 pl-[31px] box-border gap-[75px] max-w-full z-[2] mq450:gap-[37px]">
              <div className="w-full h-full absolute !m-[0] right-[0px] bottom-[-16px] left-[0px] shadow-[23.6px_-23.6px_23.63px_rgba(165,_165,_165,_0.1)_inset,_-23.6px_23.6px_23.63px_rgba(255,_255,_255,_0.1)_inset] [backdrop-filter:blur(47.27px)] rounded-36xl bg-whitesmoke-100" />
              <img
                className="w-28 h-[21px] absolute !m-[0] right-[2px] bottom-[76px] object-contain z-[1]"
                loading="lazy"
                alt=""
                src="/vector1.svg"
              />
              <div className="self-stretch flex flex-row items-start justify-end py-0 px-[23px]">
                <h2 className="m-0 w-[249px] relative text-inherit leading-[16px] font-extrabold font-inherit flex items-center shrink-0 z-[1] mq450:text-5xl mq450:leading-[10px] mq1025:text-13xl mq1025:leading-[13px]">
                  Login
                </h2>
              </div>
              <div className="self-stretch flex flex-col items-start justify-start gap-[14px] max-w-full text-5xl text-saddlebrown-400">
                <div className="self-stretch flex flex-row items-start justify-start py-0 pr-0 pl-[3px] box-border max-w-full">
                  <div className="flex-1 flex flex-col items-start justify-start gap-[1px] max-w-full">
                    <div className="self-stretch flex flex-row items-start justify-start gap-[48px] mq450:gap-[24px] mq750:flex-wrap">
                      <div className="flex-1 flex flex-row items-start justify-start min-w-[158px]">
                        <div className="flex-1 flex flex-col items-start justify-start pt-[5px] px-0 pb-0">
                          <div className="self-stretch relative leading-[16px] z-[1] mq450:text-lgi mq450:leading-[13px]">
                            EMAIL
                          </div>
                        </div>
                        <div className="flex-1 relative leading-[16px] text-saddlebrown-500 z-[1] ml-[-235px] mq450:text-lgi mq450:leading-[13px]">
                          Username
                        </div>
                      </div>
                      <div className="flex flex-col items-start justify-start pt-[13px] px-0 pb-0">
                        <div className="flex flex-row items-start justify-start relative">
                          <img
                            className="h-6 w-[104px] relative overflow-hidden shrink-0 object-contain z-[1]"
                            alt=""
                            src="/materialsymbolsperson.svg"
                          />
                          <img
                            className="h-[23px] w-6 absolute !m-[0] top-[-8px] right-[36px] z-[2]"
                            alt=""
                            src="/vector-11.svg"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="w-[372px] h-px relative max-w-full">
                      <div className="absolute top-[0px] left-[0px] box-border w-full h-full z-[1] border-t-[1px] border-solid border-black" />
                      <div className="absolute top-[0px] left-[0px] box-border w-full h-full z-[1] border-t-[1px] border-solid border-gray" />
                    </div>
                  </div>
                </div>
                <div className="w-[253px] flex flex-row items-start justify-start pt-0 px-[7px] pb-2 box-border text-saddlebrown-500">
                  <div className="flex-1 relative leading-[16px] z-[1] mq450:text-lgi mq450:leading-[13px]">
                    EMAIL
                  </div>
                </div>
                <div className="w-[375px] flex flex-col items-start justify-start gap-[1.7px] max-w-full">
                  <div className="self-stretch h-px relative box-border z-[1] border-t-[1px] border-solid border-gray" />
                  <div className="w-[251px] flex flex-row items-start justify-start py-0 px-1.5 box-border">
                    <div className="flex-1 relative leading-[16px] z-[1] mq450:text-lgi mq450:leading-[13px]">
                      Password
                    </div>
                  </div>
                  <div className="w-[245px] flex flex-row items-start justify-start py-0 px-[3px] box-border text-saddlebrown-500">
                    <div className="flex-1 relative leading-[16px] z-[1] mq450:text-lgi mq450:leading-[13px]">
                      Password
                    </div>
                  </div>
                  <div className="self-stretch h-px flex flex-row items-start justify-start py-0 pr-0 pl-[3px] box-border max-w-full">
                    <div className="self-stretch flex-1 relative box-border max-w-full z-[1] border-t-[1px] border-solid border-black" />
                  </div>
                </div>
                <div className="w-[378px] h-px flex flex-row items-start justify-start py-0 pr-0.5 pl-[3px] box-border max-w-full">
                  <div className="self-stretch flex-1 relative box-border max-w-full z-[1] border-t-[1px] border-solid border-gray" />
                </div>
              </div>
              <img
                className="w-6 h-[27px] absolute !m-[0] right-[42px] bottom-[101px] z-[2]"
                loading="lazy"
                alt=""
                src="/vector-2.svg"
              />
            </div>
          </div>
          <div className="absolute top-[0px] left-[71px] rounded-21xl bg-madpackerscom w-[306px] flex flex-row items-end justify-between pt-0.5 pb-2 pr-[9px] pl-8 box-border gap-[20px]">
            <div className="h-[49px] w-[306px] relative rounded-21xl bg-madpackerscom hidden" />
            <div className="flex flex-col items-start justify-end pt-0 pb-[3px] pr-[11px] pl-0">
              <img
                className="w-[42px] h-[30px] relative z-[1]"
                loading="lazy"
                alt=""
                src="/vector-31.svg"
              />
            </div>
            <img
              className="h-[33px] w-[37px] relative z-[3]"
              loading="lazy"
              alt=""
              src="/vector-4.svg"
            />
            <img
              className="h-[39px] w-[53px] relative overflow-hidden shrink-0 z-[3]"
              loading="lazy"
              alt=""
              src="/mdilinkedin.svg"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

FrameComponent.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent;
