import { useCallback } from "react";
import LoginName from "./login-name";
import ForgotPasswordDefault from "./forgot-password-default";
import ForgotPasswordVariant from "./forgot-password-variant";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";

const Footer = ({ className = "" }) => {
  const navigate = useNavigate();

  const onCreateAnAccountClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <footer
      className={`w-[400px] flex flex-col items-start justify-start max-w-full text-left text-xl text-saddlebrown-200 font-poppins ${className}`}
    >
      <LoginName />
      <div className="self-stretch flex flex-row items-start justify-start py-0 pr-0 pl-[39px] box-border max-w-full">
        <div className="h-[60px] flex-1 relative max-w-full">
          <ForgotPasswordDefault />
          <ForgotPasswordVariant forgotPassword="Forgot Password?" />
        </div>
      </div>
      <div className="self-stretch flex flex-row items-start justify-start py-0 pr-0 pl-[39px] box-border max-w-full">
        <div
          className="flex-1 relative [text-decoration:underline] leading-[16px] font-extrabold inline-block max-w-full cursor-pointer mq450:text-base mq450:leading-[13px]"
          onClick={onCreateAnAccountClick}
        >
          Create an account
        </div>
      </div>
    </footer>
  );
};

Footer.propTypes = {
  className: PropTypes.string,
};

export default Footer;
