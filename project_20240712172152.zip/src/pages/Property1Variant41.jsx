export default function Property1Variant41() {
  return (
    <div className="flex flex-col box-sizing-border">
      <div className="rounded-[90px] border-[1px_solid_#000000] m-[0_6.8px_4px_0] flex flex-row justify-between p-[17px_0_17px_0] w-[calc(100%_-_6.8px)] box-sizing-border">
        <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
        Select
        </span>
        <div className="m-[8.5px_0_8.8px_0] flex w-[24px] h-[24px] box-sizing-border">
          <img className="w-[8.5px] h-[5.7px]" />
        </div>
      </div>
      <div className="rounded-[20px] border-[1px_solid_#000000] flex flex-col p-[17px_0_17px_0] w-[100%] box-sizing-border">
        <div className="rounded-[90px] m-[0_16.7px_18px_16.7px] flex self-start box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Rishikesh
          </span>
        </div>
        <div className="rounded-[90px] bg-[#654C0D] m-[0_0_18px_0] flex p-[18.5px_168px_18.5px_0] w-[100%] box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Goa
          </span>
        </div>
        <div className="rounded-[90px] m-[0_168px_36px_0] flex self-center box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Manali
          </span>
        </div>
        <div className="rounded-[90px] m-[0_20.4px_36px_20.4px] flex self-start box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Amritsar
          </span>
        </div>
        <div className="rounded-[90px] m-[0_168px_36px_0] flex self-center box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Jaipur
          </span>
        </div>
        <div className="rounded-[90px] m-[0_168px_36px_0] flex self-center box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Bir
          </span>
        </div>
        <div className="rounded-[90px] m-[0_22.8px_36px_22.8px] flex self-start box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Udaipur
          </span>
        </div>
        <div className="rounded-[90px] m-[0_168px_36px_0] flex self-center box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          jibhi
          </span>
        </div>
        <div className="rounded-[90px] m-[0_21.9px_36px_21.9px] flex self-start box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Pushkar
          </span>
        </div>
        <div className="rounded-[90px] m-[0_19.2px_0_19.2px] flex self-start box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Khajurao
          </span>
        </div>
      </div>
    </div>
  )
}