export default function Property1Variant21() {
  return (
    <div className="bg-[#CDBDB1] flex flex-col box-sizing-border">
      <div className="rounded-[90px] border-[1px_solid_#000000] relative m-[0_0_31px_0] flex p-[15px_0_17.3px_136.6px] w-[100%] h-[47px] box-sizing-border">
        <span className="absolute left-[50%] top-[10px] translate-x-[-50%] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0B0B]">
        Travel Search 
        </span>
        <img className="w-[15.6px] h-[12.8px]" />
      </div>
      <div className="rounded-[90px] border-[1px_solid_#000000] flex p-[11px_3px_11px_0] w-[100%] box-sizing-border">
        <span className="border-[1px_solid_#000000] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#1D1B1B]">
        Hostel Stays
        </span>
      </div>
      <div className="rounded-[90px] border-[1px_solid_#000000] relative w-[213px] h-[47px]">
        <span className="border-[1px_solid_#000000] absolute left-[55.7px] bottom-[12px] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#1D1B1B]">
        Travel Tips
        </span>
      </div>
      <div className="rounded-[90px] border-[1px_solid_#000000] relative w-[213px] h-[47px]">
        <span className="border-[1px_solid_#000000] absolute right-[24.8px] bottom-[12px] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#1D1B1B]">
        General Discussions
        </span>
      </div>
      <div className="rounded-[90px] border-[1px_solid_#000000] relative w-[213px] h-[47px]">
        <span className="border-[1px_solid_#000000] absolute right-[19.8px] bottom-[12px] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#1D1B1B]">
        Location Suggestions
        </span>
      </div>
    </div>
  )
}