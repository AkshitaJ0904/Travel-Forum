export default function CommunityWithairbnbComByHtmlToDesignFreeVersion10072024143825Gmt530() {
  return (
    <div className="bg-[var(--community-withairbnb-com-nero,#FFFFFF)] flex p-[80px_0_0_0] w-[1920px] box-sizing-border">
      <div className="bg-[var(--community-withairbnb-com-nero,#FFFFFF)] flex flex-col items-center w-[1920px] h-[fit-content] box-sizing-border">
        <div className="m-[0_0_2px_0] flex w-[1920px] box-sizing-border">
          <div className="bg-[var(--community-withairbnb-com-nero,#FFFFFF)] flex w-[1920px] h-[fit-content] box-sizing-border">
            <div className="border-b-[1px_solid_var(--community-withairbnb-com-alto,#DDDDDD)] bg-[var(--community-withairbnb-com-nero,#FFFFFF)] flex flex-row justify-between p-[13.5px_73px_13.5px_0] w-[1920px] h-[fit-content] box-sizing-border">
              <div className="relative m-[1.5px_0_1.5px_0] flex p-[0_354px_0_354px] w-[880px] h-[fit-content] box-sizing-border">
                <div className="relative flex flex-row w-[256px] h-[fit-content] box-sizing-border">
                  <div className="m-[14.6px_13.9px_11.9px_0] flex w-[24px] h-[26.7px] box-sizing-border">
                    <img className="w-[20.3px] h-[22.5px]" />
                  </div>
                  <div className="flex w-[232px] box-sizing-border">
                    <div className="border-[1px_solid_var(--community-withairbnb-com-nero,#FFFFFF)] flex flex-row p-[12px_0_12px_0] w-[220px] h-[fit-content] box-sizing-border">
                      <div className="m-[0_14.3px_0_0] flex box-sizing-border">
                        <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                        Community Center
                        </span>
                      </div>
                      <div className="m-[9.6px_0_8px_0] flex w-[19px] h-[15px] box-sizing-border">
                        <img className="w-[11.3px] h-[5.4px]" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="absolute left-[50%] bottom-[0.5px] translate-x-[-50%] flex w-[354px] h-[79px] box-sizing-border">
                  <div className="relative p-[16.4px_13.4px_19.4px_13.4px] w-[338px] h-[48px] box-sizing-border">
                    <span className="break-words font-['Inter'] font-[var(--community-withairbnb-com-inter-medium-1575,500)] text-[15.8px] text-[var(--community-withairbnb-com-silver-chalice,#A9A9A9)]">
                    Search the community
                    </span>
                    <div className="shadow-[0px_0px_0px_1px_rgba(0,0,0,0.03),0px_2px_4px_0px_rgba(0,0,0,0.06)] rounded-[8px] border-[1px_solid_var(--community-withairbnb-com-gray-nurse,#DFE0DF)] bg-[var(--community-withairbnb-com-nero,#FFFFFF)] absolute left-[50%] top-[0px] translate-x-[-50%] p-[12px_0_15px_32px] w-[338px] h-[48px] box-sizing-border">
                      <span className="break-words font-['Inter'] font-[var(--community-withairbnb-com-inter-medium-1575,500)] text-[15.8px] text-[var(--community-withairbnb-com-silver-chalice,#A9A9A9)]">
                      Search the community
                      </span>
                    </div>
                    <div className="relative flex w-[17px] h-[17px] box-sizing-border">
                      <img className="w-[12.3px] h-[12.3px]" />
                    </div>
                  </div>
                  <div className="rounded-[8px] absolute left-[0px] bottom-[10.5px] flex box-sizing-border">
                    <span className="break-words font-['Inter'] font-[var(--community-withairbnb-com-inter-medium-155-font-weight,500)] text-[15.5px] leading-[var(--community-withairbnb-com-inter-medium-155-line-height,1.29)] text-[var(--community-withairbnb-com-tundora,#484848)]">
                    Search
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex flex-row box-sizing-border">
                <div className="m-[0_12px_0_0] flex w-[98px] box-sizing-border">
                  <div className="rounded-[8px] border-[2px_solid_var(--community-withairbnb-com-nero,#FFFFFF)] bg-[var(--community-withairbnb-com-mine-shaft-1,#222222)] flex p-[14px_0_14px_0] w-[86px] h-[fit-content] box-sizing-border">
                    <span className="break-words font-['Inter'] font-medium text-[15.6px] leading-[1.28] text-[var(--community-withairbnb-com-nero,#FFFFFF)]">
                    Post
                    </span>
                  </div>
                </div>
                <div className="m-[3.5px_12px_3.5px_0] flex w-[57px] h-[79px] box-sizing-border">
                  <div className="border-[1px_solid_var(--community-withairbnb-com-nero,#FFFFFF)] bg-[var(--community-withairbnb-com-nero,#FFFFFF)] flex p-[13.8px_13.7px_13.8px_13.8px] w-[45px] h-[45px] box-sizing-border">
                    <img className="w-[15.5px] h-[15.5px]" />
                  </div>
                </div>
                <div className="relative m-[6px_0_6px_0] flex p-[0_7px_0_0] box-sizing-border">
                  <div className="rounded-[50px] border-[1px_solid_var(--community-withairbnb-com-alto,#DDDDDD)] flex p-[7px_16.5px_8px_14.9px] box-sizing-border">
                    <span className="break-words font-['Inter'] font-bold text-[13.7px] leading-[1.682] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                    Log In
                    </span>
                  </div>
                  <div className="rounded-[10px] bg-[var(--community-withairbnb-com-amaranth,#E61E4E)] absolute top-[4.5px] right-[0px] w-[20px] h-[20px]">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col items-center w-[1920px] box-sizing-border">
          <div className="m-[0_0_29px_0] box-sizing-border">
            <div className="rounded-[2px] bg-[var(--community-withairbnb-com-nero,#FFFFFF)] flex flex-col p-[3px_0_0_0] box-sizing-border">
              <div className="m-[0_0_72px_0] flex self-start box-sizing-border">
                <span className="break-words font-['Inter'] font-medium text-[39.1px] leading-[1.331] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                Start a conversation
                </span>
              </div>
              <div className="flex flex-col w-[fit-content] box-sizing-border">
                <div className="m-[0_0_203px_0] flex flex-col w-[fit-content] box-sizing-border">
                  <div className="m-[0_0_18px_0] flex flex-col w-[fit-content] box-sizing-border">
                    <div className="m-[0_0_40px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-medium text-[31.6px] leading-[1.138] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      1. What do you want to talk about?
                      </span>
                    </div>
                    <div className="box-sizing-border">
                      <div className="shadow-[inset_0px_1px_1px_1px_rgba(0,0,0,0.075),0px_0px_8px_0px_rgba(0,0,0,0.6)] rounded-[12px] border-[1px_solid_var(--community-withairbnb-com-black,#000000)] bg-[var(--community-withairbnb-com-nero,#FFFFFF)] p-[26px_24px_27.4px_24px] box-sizing-border">
                        <span className="break-words font-['Inter'] font-[var(--community-withairbnb-com-inter-light-1758,300)] text-[17.6px] text-[var(--community-withairbnb-com-silver-chalice,#A9A9A9)]">
                        Enter a subject
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="m-[0_1.4px_310px_1.4px] flex self-end box-sizing-border">
                    <span className="break-words font-['Inter'] font-normal text-[11.6px] leading-[1.978] uppercase text-[var(--community-withairbnb-com-tundora,#484848)]">
                    Preview
                    </span>
                  </div>
                  <div className="m-[0_0_15px_0] flex flex-row self-start w-[fit-content] box-sizing-border">
                    <span className="m-[0_14.2px_0_0] break-words font-['Inter'] font-normal text-[15.5px] leading-[1.484] text-[var(--community-withairbnb-com-lemon-grass,#9CA299)]">
                    By using the Community Center, you agree to adhere to the 
                    </span>
                    <div className="m-[0_6.1px_0_0] flex box-sizing-border">
                      <span className="break-words font-['Inter'] font-normal text-[15.6px] underline leading-[1.472] text-[var(--community-withairbnb-com-cod-gray,#1A1A1A)]">
                      Community Center Guidelines
                      </span>
                    </div>
                    <span className="break-words font-['Inter'] font-normal text-[16px] leading-[1.438] text-[var(--community-withairbnb-com-lemon-grass,#9CA299)]">
                    .
                    </span>
                  </div>
                  <div className="self-start box-sizing-border">
                    <div className="rounded-[12px] border-[2px_solid_var(--community-withairbnb-com-mine-shaft-1,#222222)] bg-[var(--community-withairbnb-com-silver,#CCCCCC)] relative p-[85px_20px_53px_20px] box-sizing-border">
                      <div className="flex box-sizing-border">
                        <span className="break-words font-['Inter'] font-medium text-[17.9px] leading-[1.232] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                        Hosting
                        </span>
                      </div>
                      <div className="absolute top-[27.9px] right-[27.9px] flex w-[12px] h-[12px] box-sizing-border">
                        <img className="w-[10.3px] h-[10.3px]" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="border-t-[1px_solid_var(--community-withairbnb-com-alto,#DDDDDD)] flex flex-row justify-between p-[46px_0_5px_0.9px] w-[1064px] box-sizing-border">
                  <div className="m-[14px_0_14px_0] flex box-sizing-border">
                    <span className="break-words font-['Inter'] font-medium text-[15.8px] underline leading-[1.27] text-[var(--community-withairbnb-com-tundora,#484848)]">
                    Cancel
                    </span>
                  </div>
                  <div className="flex w-[120.6px] h-[fit-content] box-sizing-border">
                    <div className="rounded-[8px] bg-[var(--community-withairbnb-com-mine-shaft-1,#222222)] flex p-[14px_0px_14px_0] w-[120.6px] h-[fit-content] box-sizing-border">
                      <span className="break-words font-['Inter'] font-medium text-[15.6px] leading-[1.28] text-[var(--community-withairbnb-com-nero,#FFFFFF)]">
                      Post
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="flex w-[1920px] box-sizing-border">
            <div className="bg-[var(--community-withairbnb-com-wild-sand,#F7F7F7)] flex flex-col items-center p-[48px_0_0px_0] w-[1920px] h-[fit-content] box-sizing-border">
              <div className="m-[0_3.2px_51.8px_0] flex flex-row w-[fit-content] box-sizing-border">
                <div className="m-[0_257.9px_0_0] flex flex-col box-sizing-border">
                  <div className="m-[0_0_17.5px_0] flex self-start box-sizing-border">
                    <span className="break-words font-['Inter'] font-[var(--community-withairbnb-com-inter-bold-1378-font-weight,700)] text-[13.8px] leading-[var(--community-withairbnb-com-inter-bold-1378-line-height,1.219)] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                    Support
                    </span>
                  </div>
                  <div className="flex flex-col w-[fit-content] box-sizing-border">
                    <div className="m-[0_0_18px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.8px] leading-[1.669] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Help Center
                      </span>
                    </div>
                    <div className="m-[0_0_18px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[14px] leading-[1.643] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      AirCover
                      </span>
                    </div>
                    <div className="m-[0_0_18px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.9px] leading-[1.656] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Anti-Discrimination
                      </span>
                    </div>
                    <div className="m-[0_0_18px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.9px] leading-[1.656] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Disability support
                      </span>
                    </div>
                    <div className="m-[0_0_18px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.8px] leading-[1.669] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Cancellation options
                      </span>
                    </div>
                    <div className="flex box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.9px] leading-[1.656] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Report neighborhood concern
                      </span>
                    </div>
                  </div>
                </div>
                <div className="m-[0_258px_0_0] flex flex-col box-sizing-border">
                  <div className="m-[0_0_17.5px_0] flex self-start box-sizing-border">
                    <span className="break-words font-['Inter'] font-[var(--community-withairbnb-com-inter-bold-1367-font-weight,700)] text-[13.7px] leading-[var(--community-withairbnb-com-inter-bold-1367-line-height,1.229)] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                    Hosting
                    </span>
                  </div>
                  <div className="flex flex-col w-[fit-content] box-sizing-border">
                    <div className="m-[0_0_18px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.9px] leading-[1.656] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Airbnb your home
                      </span>
                    </div>
                    <div className="m-[0_0_18px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.9px] leading-[1.656] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      AirCover for Hosts
                      </span>
                    </div>
                    <div className="m-[0_0_18px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.7px] leading-[1.682] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Hosting resources
                      </span>
                    </div>
                    <div className="m-[0_0_18px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[14px] leading-[1.643] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Community forum
                      </span>
                    </div>
                    <div className="m-[0_0_18px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.7px] leading-[1.682] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Hosting responsibly
                      </span>
                    </div>
                    <div className="flex box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.9px] leading-[1.656] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Airbnb-friendly apartments
                      </span>
                    </div>
                  </div>
                </div>
                <div className="m-[0_0px_0_0] flex flex-col box-sizing-border">
                  <div className="m-[0_0_17.5px_0] flex self-start box-sizing-border">
                    <span className="break-words font-['Inter'] font-[var(--community-withairbnb-com-inter-bold-1378-font-weight,700)] text-[13.8px] leading-[var(--community-withairbnb-com-inter-bold-1378-line-height,1.219)] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                    Airbnb
                    </span>
                  </div>
                  <div className="flex flex-col w-[fit-content] box-sizing-border">
                    <div className="m-[0_0_18px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.9px] leading-[1.656] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Newsroom
                      </span>
                    </div>
                    <div className="m-[0_0_18px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.7px] leading-[1.682] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      New features
                      </span>
                    </div>
                    <div className="m-[0_0_18px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.8px] leading-[1.669] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Careers
                      </span>
                    </div>
                    <div className="m-[0_0_18px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.8px] leading-[1.669] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Investors
                      </span>
                    </div>
                    <div className="m-[0_0_18px_0] flex self-start box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.9px] leading-[1.656] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Gift cards
                      </span>
                    </div>
                    <div className="flex box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.8px] leading-[1.669] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Airbnb.org emergency stays
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="border-t-[1px_solid_var(--community-withairbnb-com-alto,#DDDDDD)] flex flex-row p-[23.5px_0_24.5px_0] w-[1064px] box-sizing-border">
                <div className="relative m-[0.5px_8.2px_0_0] flex p-[0_2.9px_0_0] box-sizing-border">
                  <span className="relative break-words font-['Inter'] font-light text-[13.5px] leading-[1.71] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                  © 2024 Airbnb, Inc. All rights reserved
                  </span>
                  <span className="absolute right-[0px] bottom-[0px] break-words font-['Inter'] font-light text-[14px] leading-[1.643] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                  ·
                  </span>
                </div>
                <div className="flex flex-row box-sizing-border">
                  <div className="m-[0.5px_8.2px_0_0] flex flex-row box-sizing-border">
                    <div className="m-[0_6.7px_0_0] flex box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.5px] leading-[1.71] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Privacy
                      </span>
                    </div>
                    <span className="break-words font-['Inter'] font-light text-[14px] leading-[1.643] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                    ·
                    </span>
                  </div>
                  <div className="m-[0.5px_8.2px_0_0] flex flex-row box-sizing-border">
                    <div className="m-[0_8.6px_0_0] flex box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.9px] leading-[1.656] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Terms
                      </span>
                    </div>
                    <span className="break-words font-['Inter'] font-light text-[14px] leading-[1.643] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                    ·
                    </span>
                  </div>
                  <div className="m-[0.5px_8.2px_0_0] flex flex-row box-sizing-border">
                    <div className="m-[0_11.2px_0_0] flex box-sizing-border">
                      <span className="break-words font-['Inter'] font-light text-[13.6px] leading-[1.696] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                      Cookie Policy
                      </span>
                    </div>
                    <span className="m-[0_0px_0_0] break-words font-['Inter'] font-light text-[14px] leading-[1.643] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                    ·
                    </span>
                  </div>
                  <div className="m-[0_7.5px_0.5px_0] flex flex-row box-sizing-border">
                    <img className="m-[3.5px_11.1px_7.5px_0] w-[26px] h-[12px]" />
                    <span className="break-words font-['Inter'] font-[var(--community-withairbnb-com-inter-light-14-font-weight,300)] text-[14px] leading-[var(--community-withairbnb-com-inter-light-14-line-height,1.643)] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                    ·
                    </span>
                  </div>
                  <div className="m-[0.5px_0px_0_0] flex box-sizing-border">
                    <span className="break-words font-['Inter'] font-light text-[13.5px] leading-[1.71] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                    Site Map
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}