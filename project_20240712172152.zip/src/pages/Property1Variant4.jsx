export default function Property1Variant4() {
  return (
    <div className="bg-[var(--bg-for-drop-down-background-image,linear-gradient(180deg,#DA914D,#D9A651,#D9DB5C))] bg-[var(--bg-for-drop-down-background-position-x,)_var(--bg-for-drop-down-background-position-y,)] bg-[length:var(--bg-for-drop-down-background-size,)] bg-var(--bg-for-drop-down-background-repeat, ) bg-var( bg-var( flex flex-col p-[0_0_78px_0] box-sizing-border">
      <div className="rounded-[90px] border-[1px_solid_var(--madpackers-com-mine-shaft,#333333)] m-[0_0_24px_0] flex flex-row justify-between p-[12px_0_12px_0] w-[100%] box-sizing-border">
        <div className="flex box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
          Travel Search
          </span>
        </div>
        <div className="m-[8px_0_9.6px_0] flex w-[19px] h-[15px] box-sizing-border">
          <img className="w-[11.3px] h-[5.4px]" />
        </div>
      </div>
      <div className="rounded-[90px] flex flex-col w-[100%] box-sizing-border">
        <div className="border-[1px_solid_var(--madpackers-com-mine-shaft,#333333)] flex p-[12px_0_12px_0] w-[100%] box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
           Hostel stays
          </span>
        </div>
        <div className="bg-[#F4E244] p-[1px_0_1px_0] w-[100%] box-sizing-border">
          <div className="border-[1px_solid_var(--madpackers-com-mine-shaft,#333333)] flex p-[12px_0_12px_0] w-[100%] h-[fit-content] box-sizing-border">
            <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
            General Discussion
            </span>
          </div>
        </div>
        <div className="border-[1px_solid_var(--madpackers-com-mine-shaft,#333333)] flex p-[12px_0_12px_0] w-[100%] box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
          Travel Tips
          </span>
        </div>
        <div className="border-[1px_solid_var(--madpackers-com-mine-shaft,#333333)] flex p-[12px_0_12px_0] w-[100%] box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
          Location  Suggestions
          </span>
        </div>
      </div>
    </div>
  )
}