export default function Frame25() {
  return (
    <div className="rounded-[20px] border-[1px_solid_#000000] bg-[#D9D9D9] flex flex-col items-end p-[53px_15px_26px_0] box-sizing-border">
      <div className="m-[0_52.5px_26px_0] inline-block self-center break-words font-['Inter'] font-medium text-[40px] leading-[0.575] bg-[linear-gradient(#0C0C0C,#0C0C0C)] text-[transparent] bg-clip-text">
      Choose a location
      </div>
      <div className="relative flex box-sizing-border">
        <div className="relative flex flex-row box-sizing-border">
          <div className="m-[0_147.8px_0_0] flex flex-col items-center box-sizing-border">
            <div className="rounded-[90px] m-[0_0_36.5px_0] flex box-sizing-border">
              <span className="break-words font-['Inter'] font-medium text-[25px] leading-[0.92] text-[#000000]">
              Rishikesh
              </span>
            </div>
            <div className="rounded-[90px] m-[0_8px_36.5px_0] flex box-sizing-border">
              <span className="break-words font-['Inter'] font-medium text-[25px] leading-[0.92] text-[#000000]">
              Goa
              </span>
            </div>
            <div className="rounded-[90px] m-[0_19.6px_36px_15.6px] flex box-sizing-border">
              <span className="break-words font-['Inter'] font-medium text-[25px] leading-[0.92] text-[#000000]">
              Manali
              </span>
            </div>
            <div className="rounded-[90px] m-[0_5.4px_36px_6.4px] flex box-sizing-border">
              <span className="break-words font-['Inter'] font-medium text-[25px] leading-[0.92] text-[#000000]">
              Amritsar
              </span>
            </div>
            <div className="rounded-[90px] m-[0_19.7px_36px_19.7px] flex box-sizing-border">
              <span className="break-words font-['Inter'] font-medium text-[25px] leading-[0.92] text-[#000000]">
              Jaipur
              </span>
            </div>
            <div className="rounded-[90px] m-[0_0_36px_1px] flex box-sizing-border">
              <span className="break-words font-['Inter'] font-medium text-[25px] leading-[0.92] text-[#000000]">
              Bir
              </span>
            </div>
            <div className="rounded-[90px] m-[0_7.5px_36px_11.5px] flex box-sizing-border">
              <span className="break-words font-['Inter'] font-medium text-[25px] leading-[0.92] text-[#000000]">
              Udaipur
              </span>
            </div>
            <div className="rounded-[90px] m-[0_0_36px_1px] flex box-sizing-border">
              <span className="break-words font-['Inter'] font-medium text-[25px] leading-[0.92] text-[#000000]">
              jibhi
              </span>
            </div>
            <div className="rounded-[90px] m-[0_7.2px_36px_9.2px] flex box-sizing-border">
              <span className="break-words font-['Inter'] font-medium text-[25px] leading-[0.92] text-[#000000]">
              Pushkar
              </span>
            </div>
            <div className="rounded-[90px] m-[0_2.9px_0_4.9px] flex box-sizing-border">
              <span className="break-words font-['Inter'] font-medium text-[25px] leading-[0.92] text-[#000000]">
              Khajurao
              </span>
            </div>
          </div>
          <div className="rounded-[90px] bg-[#9F9B9B] m-[19px_0_123px_0] w-[21px] h-[413px]">
          </div>
        </div>
        <img className="rounded-[90px] absolute right-[0px] bottom-[124px] w-[22px] h-[112px]" />
      </div>
    </div>
  )
}