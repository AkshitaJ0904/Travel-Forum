export default function SelectorMain() {
  return (
    <div className="flex p-[14px_0_20.3px_134.6px] box-sizing-border">
      <span className="absolute left-[50%] top-[10px] translate-x-[-50%] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
      Travel Search 
      </span>
      <div className="rounded-[90px] border-[1px_solid_#000000] absolute left-[0px] top-[0px] right-[0px] bottom-[0px] h-[100%]">
        <span className="absolute left-[50%] top-[10px] translate-x-[-50%] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
        Travel Search 
        </span>
      </div>
      <img className="relative w-[15.6px] h-[12.8px]" />
    </div>
  )
}