export default function Webpage2() {
  return (
    <div className="flex w-[1280px] box-sizing-border">
      <div className="bg-[linear-gradient(195deg,#BD721A_-8.8%,#D5B440_15.87%,#C89039_32.9%)] flex flex-col items-center p-[127px_0_179px_0] w-[1280px] h-[fit-content] box-sizing-border">
        <div className="rounded-[40px] bg-[#CD9529] relative m-[0_417px_24px_0] flex flex-row justify-between p-[9px_21.6px_9.9px_26px] w-[306px] box-sizing-border">
          <img className="m-[0_0_3.4px_0] w-[42px] h-[26.8px]" />
          <img className="m-[0_0_0.7px_0] w-[37px] h-[29.4px]" />
          <div className="m-[0.9px_0_0_0] flex w-[53px] h-[39px] box-sizing-border">
            <img className="w-[39.8px] h-[29.3px]" />
          </div>
        </div>
        <div className="m-[0_0_33px_0] flex flex-row w-[402px] box-sizing-border">
          <div className="shadow-[inset_23.6px_-23.6px_23.6px_0px_rgba(165,165,165,0.1),inset_-23.6px_23.6px_23.6px_0px_rgba(255,255,255,0.1)] backdrop-blur-[23.6px] rounded-[55px] bg-[rgba(250,248,248,0.46)] relative m-[0_0_2px_0] flex flex-col items-center p-[48.5px_0_107px_0] w-[501px] h-[fit-content] box-sizing-border">
            <div className="m-[0_17.3px_61.5px_0] inline-block break-words font-['Poppins'] font-extrabold text-[40px] leading-[0.4] text-[#704A10]">
            Sign Up
            </div>
            <div className="m-[0_0.3px_20.5px_0] flex flex-row justify-between w-[372px] box-sizing-border">
              <div className="m-[8.5px_8px_0_0] inline-block w-[239px] break-words font-['Poppins'] font-normal text-[24px] leading-[0.667] text-[#62360C]">
              Username
              </div>
              <div className="m-[0_0_8.5px_0] flex w-[24px] h-[24px] box-sizing-border">
                <img className="w-[16px] h-[16px]" />
              </div>
            </div>
            <div className="bg-[#000000] m-[0_0.3px_23px_0] w-[372px] h-[0px]">
            </div>
            <div className="m-[0_0_17.5px_0] flex flex-row justify-between w-[372.3px] box-sizing-border">
              <div className="m-[1.5px_8px_0_0] inline-block w-[239px] break-words font-['Poppins'] font-normal text-[24px] leading-[0.667] text-[#62360C]">
              EMAIL
              </div>
              <img className="m-[0_0_5px_0] w-[20.3px] h-[12.5px]" />
            </div>
            <div className="bg-[#000000] m-[0_0.3px_17px_0] w-[372px] h-[0px]">
            </div>
            <div className="m-[0_0.5px_8.5px_0] flex flex-row justify-between w-[371.8px] box-sizing-border">
              <div className="m-[8.5px_8px_0_0] inline-block w-[239px] break-words font-['Poppins'] font-normal text-[24px] leading-[0.667] text-[#62360C]">
              Password
              </div>
              <img className="m-[0_0_7px_0] w-[14.8px] h-[17.5px]" />
            </div>
            <div className="bg-[#000000] m-[0_0.3px_0_0] w-[372px] h-[0px]">
            </div>
          </div>
          <div className="shadow-[0px_45px_50px_0px_rgba(0,0,0,0.25)] rounded-[50px] bg-[url('assets/images/Image1.png')] bg-[50%_50%] bg-cover bg-no-repeat w-[416px] h-[391px]">
          </div>
        </div>
        <div className="rounded-[90px] bg-[linear-gradient(90deg,#EE801A,#EF871A,#F0D715,#F0E715)] relative m-[0_429px_22px_0] flex p-[29px_0_29px_6.1px] w-[286px] box-sizing-border">
          <span className="break-words font-['Poppins'] font-extrabold text-[32px] leading-[0.5] text-[#D6CCBD]">
          Sign Up
          </span>
        </div>
        <div className="m-[0_411.6px_0_0] flex box-sizing-border">
          <span className="break-words font-['Poppins'] font-extrabold text-[20px] underline leading-[0.8] text-[#834C0D]">
          Already have an account?
          </span>
        </div>
      </div>
    </div>
  )
}