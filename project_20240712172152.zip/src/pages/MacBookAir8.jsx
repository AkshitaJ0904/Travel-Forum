export default function MacBookAir8() {
  return (
    <div className="bg-[#270707] flex p-[9px_0_0_12px] w-[1235px] box-sizing-border">
      <div className="absolute left-[7.8px] top-[9.3px] flex w-[24px] h-[24px] box-sizing-border">
        <img className="w-[8.5px] h-[5.7px]" />
      </div>
      <div className="bg-[linear-gradient(195deg,#D3B484_-5.6%,#92764D_-3.73%,#D3B753_7.53%,#DCB67C_32.9%)] relative flex flex-col items-center p-[34px_33px_297px_29px] w-[1241px] h-[fit-content] box-sizing-border">
        <img className="absolute top-[262px] right-[353px] w-[487px] h-[439px]" />
        <div className="rounded-[90px] border-b-[1px_solid_var(--community-withairbnb-com-alto,#DDDDDD)] bg-[var(--community-withairbnb-com-wild-sand,#F7F7F7)] relative m-[0_0_327px_0] flex flex-row p-[13.5px_0_13.5px_0] w-[1179px] box-sizing-border">
          <div className="relative m-[2px_27px_2px_0] flex w-[353px] h-[79px] box-sizing-border">
            <div className="relative p-[16.4px_13.4px_19.4px_13.4px] w-[338px] h-[48px] box-sizing-border">
              <span className="break-words font-['Inter'] font-[var(--community-withairbnb-com-inter-medium-1575,500)] text-[15.8px] text-[var(--colors-orange,#FF9500)]">
              Search<br />
              
              </span>
              <div className="shadow-[0px_0px_0px_1px_rgba(0,0,0,0.03),0px_2px_4px_0px_rgba(0,0,0,0.06)] rounded-[8px] border-[1px_solid_var(--community-withairbnb-com-tundora,#484848)] bg-[var(--community-withairbnb-com-wild-sand,#F7F7F7)] absolute left-[50%] top-[0px] translate-x-[-50%] p-[21.5px_0_5.5px_32px] w-[338px] h-[48px] box-sizing-border">
                <span className="break-words font-['Inter'] font-[var(--community-withairbnb-com-inter-medium-1575,500)] text-[15.8px] text-[var(--colors-orange,#FF9500)]">
                Search<br />
                
                </span>
              </div>
              <div className="relative flex w-[17px] h-[17px] box-sizing-border">
                <img className="w-[12.3px] h-[12.3px]" />
              </div>
            </div>
            <div className="rounded-[8px] absolute left-[0px] bottom-[10.5px] flex box-sizing-border">
              <span className="break-words font-['Inter'] font-[var(--community-withairbnb-com-inter-medium-155-font-weight,500)] text-[15.5px] leading-[var(--community-withairbnb-com-inter-medium-155-line-height,1.29)] text-[var(--community-withairbnb-com-tundora,#484848)]">
              Search
              </span>
            </div>
          </div>
          <div className="m-[0_39.2px_0_0] flex flex-row box-sizing-border">
            <div className="m-[0_12px_0_0] flex w-[98px] box-sizing-border">
              <div className="rounded-[8px] border-[2px_solid_var(--madpackers-com-mine-shaft,#333333)] bg-[var(--community-withairbnb-com-green,#FFB400)] flex p-[14px_0_14px_0] w-[86px] h-[fit-content] box-sizing-border">
                <span className="break-words font-['Inter'] font-medium text-[15.6px] leading-[1.28] text-[var(--madpackers-com-mine-shaft,#333333)]">
                Post
                </span>
              </div>
            </div>
            <div className="m-[3.5px_12px_3.5px_0] flex w-[57px] h-[79px] box-sizing-border">
              <div className="border-[1px_solid_var(--community-withairbnb-com-wild-sand,#F7F7F7)] bg-[var(--community-withairbnb-com-wild-sand,#F7F7F7)] flex p-[13.8px_13.7px_13.8px_13.8px] w-[45px] h-[45px] box-sizing-border">
                <img className="w-[15.5px] h-[15.5px]" />
              </div>
            </div>
            <div className="m-[6px_0_6px_0] flex box-sizing-border">
              <div className="rounded-[50px] border-[1px_solid_var(--community-withairbnb-com-green,#FFB400)] flex p-[7px_16.5px_8px_14.9px] box-sizing-border">
                <span className="break-words font-['Inter'] font-bold text-[13.7px] underline leading-[1.682] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                Log In
                </span>
              </div>
            </div>
          </div>
          <div className="relative m-[2.5px_0_2.5px_0] flex p-[14px_0_20.3px_134.6px] w-[213px] h-[266px] box-sizing-border">
            <span className="absolute left-[50%] top-[10px] translate-x-[-50%] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
            Travel Search 
            </span>
            <div className="rounded-[90px] border-[1px_solid_#000000] absolute left-[50%] top-[0px] translate-x-[-50%] w-[213px] h-[47px]">
              <span className="absolute left-[50%] top-[10px] translate-x-[-50%] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
              Travel Search 
              </span>
            </div>
            <img className="relative w-[15.6px] h-[12.8px]" />
          </div>
        </div>
        <div className="relative m-[0_0_381px_52px] inline-block text-center break-words font-['Inria_Serif'] font-normal text-[45px] leading-[0.444] text-[#000000]">
        Post<br />
         <br />
        Successful !
        </div>
        <div className="bg-[#978B8B] relative m-[0_1px_32px_9px] w-[1169px] h-[0px]">
        </div>
        <div className="relative m-[0_88px_0_0] flex flex-row justify-between w-[899px] box-sizing-border">
          <div className="rounded-[8px] border-[2px_solid_var(--madpackers-com-mine-shaft,#333333)] bg-[var(--community-withairbnb-com-alto,#DDDDDD)] flex p-[14px_0_14px_0] w-[230px] box-sizing-border">
            <span className="break-words font-['Inter'] font-medium text-[20px] leading-[1] text-[var(--madpackers-com-mine-shaft,#333333)]">
            Go Back!
            </span>
          </div>
          <div className="rounded-[8px] border-[2px_solid_var(--madpackers-com-mine-shaft,#333333)] bg-[var(--community-withairbnb-com-green,#FFB400)] flex p-[14px_0_14px_0] w-[230px] box-sizing-border">
            <span className="break-words font-['Inter'] font-medium text-[20px] leading-[1] text-[var(--madpackers-com-mine-shaft,#333333)]">
            Post More!
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}