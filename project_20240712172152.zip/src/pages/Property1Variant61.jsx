export default function Property1Variant61() {
  return (
    <div className="bg-[#CDBDB1] flex flex-col box-sizing-border">
      <div className="rounded-[90px] border-[1px_solid_#0C0C0C] relative m-[0_0_31px_0] flex p-[13px_0_19.3px_118.6px] w-[100%] h-[47px] box-sizing-border">
        <span className="absolute left-[53px] top-[10px] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0A0A0A]">
        Travel Search 
        </span>
        <img className="w-[15.6px] h-[12.8px]" />
      </div>
      <div className="rounded-[90px] border-[1px_solid_#0C0C0C] m-[0_0_0_8px] flex p-[11px_0_11px_3px] w-[calc(100%_-_8px)] box-sizing-border">
        <span className="border-[1px_solid_#0C0C0C] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0A0A0A]">
        Hostel Stays
        </span>
      </div>
      <div className="rounded-[90px] border-[1px_solid_#0C0C0C] relative w-[221px] h-[47px]">
        <span className="border-[1px_solid_#0C0C0C] absolute left-[50%] bottom-[12px] translate-x-[-50%] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0A0A0A]">
        Travel Tips
        </span>
      </div>
      <div className="rounded-[90px] border-[1px_solid_#0C0C0C] relative w-[221px] h-[47px]">
        <span className="border-[1px_solid_#0C0C0C] absolute right-[27.8px] bottom-[12px] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0A0A0A]">
        General Discussions
        </span>
      </div>
      <div className="rounded-[90px] border-[1px_solid_#0C0C0C] bg-[#93772E] relative w-[221px] h-[47px]">
        <span className="border-[1px_solid_#0C0C0C] absolute right-[23.8px] bottom-[12px] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0A0A0A]">
        Location Suggestions
        </span>
      </div>
    </div>
  )
}