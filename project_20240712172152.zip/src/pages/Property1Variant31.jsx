export default function Property1Variant31() {
  return (
    <div className="bg-[#CDBDB1] flex flex-col box-sizing-border">
      <div className="rounded-[90px] border-[1px_solid_#000000] relative m-[0_0_31px_0] flex p-[17px_0_15.3px_140.6px] w-[100%] h-[47px] box-sizing-border">
        <span className="absolute right-[54px] bottom-[12px] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#080808]">
        Travel Search 
        </span>
        <img className="w-[15.6px] h-[12.8px]" />
      </div>
      <div className="rounded-[90px] border-[1px_solid_#000000] bg-[#936826] relative w-[221px] h-[47px]">
        <div className="bg-[#93772E] absolute right-[-8px] bottom-[0px] w-[229px] h-[47px]">
          <span className="border-[1px_solid_#000000] absolute left-[50%] bottom-[12px] translate-x-[-50%] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#080808]">
          Hostel Stays
          </span>
        </div>
      </div>
      <div className="rounded-[90px] border-[1px_solid_#000000] relative w-[221px] h-[47px]">
        <span className="border-[1px_solid_#000000] absolute left-[50%] bottom-[12px] translate-x-[-50%] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#080808]">
        Travel Tips
        </span>
      </div>
      <div className="rounded-[90px] border-[1px_solid_#000000] relative w-[221px] h-[47px]">
        <span className="border-[1px_solid_#000000] absolute left-[50%] bottom-[12px] translate-x-[-50%] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#080808]">
        General Discussions
        </span>
      </div>
      <div className="rounded-[90px] border-[1px_solid_#000000] relative w-[221px] h-[47px]">
        <span className="border-[1px_solid_#000000] absolute left-[50%] bottom-[12px] translate-x-[-50%] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#080808]">
        Location Suggestions
        </span>
      </div>
    </div>
  )
}