export default function Frame31() {
  return (
    <div className="rounded-[20px] border-[1px_solid_#000000] flex p-[52px_45px_52px_0] box-sizing-border">
      <div className="rounded-[20px] border-[1px_solid_#000000] bg-[#D9D9D9] absolute left-[0px] top-[0px] right-[0px] bottom-[0px] h-[100%]">
      </div>
      <span className="relative break-words font-['Inter'] font-medium text-[40px] leading-[0.575] text-[#0C0C0C]">
      Bir
      </span>
    </div>
  )
}