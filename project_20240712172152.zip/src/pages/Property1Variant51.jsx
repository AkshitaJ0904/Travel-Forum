export default function Property1Variant51() {
  return (
    <div className="bg-[#CDBDB1] flex flex-col box-sizing-border">
      <div className="rounded-[90px] border-[1px_solid_#0C0C0C] relative m-[0_0_31px_0] flex p-[14px_0_18.3px_110.6px] w-[100%] h-[47px] box-sizing-border">
        <span className="absolute left-[54px] top-[10px] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0B0B]">
        Travel Search 
        </span>
        <img className="w-[15.6px] h-[12.8px]" />
      </div>
      <div className="rounded-[90px] border-[1px_solid_#0C0C0C] flex p-[11px_9px_11px_0] w-[100%] box-sizing-border">
        <span className="border-[1px_solid_#0C0C0C] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0A0A0A]">
        Hostel Stays
        </span>
      </div>
      <div className="rounded-[90px] border-[1px_solid_#0C0C0C] relative w-[221px] h-[47px]">
        <span className="border-[1px_solid_#0C0C0C] absolute left-[64.2px] bottom-[12px] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0A0A0A]">
        Travel Tips
        </span>
      </div>
      <div className="rounded-[90px] border-[1px_solid_#0C0C0C] relative w-[221px] h-[47px]">
        <div className="bg-[#93772E] absolute left-[0px] top-[0px] right-[0px] bottom-[0px] h-[100%]">
          <span className="border-[1px_solid_#0C0C0C] absolute left-[50%] bottom-[12px] translate-x-[-50%] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0A0A0A]">
          General Discussions
          </span>
        </div>
      </div>
      <div className="rounded-[90px] border-[1px_solid_#0C0C0C] flex p-[11px_0_11px_6px] w-[100%] box-sizing-border">
        <span className="border-[1px_solid_#0C0C0C] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0A0A0A]">
        Location Suggestions
        </span>
      </div>
    </div>
  )
}