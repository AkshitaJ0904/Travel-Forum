export default function Webpage() {
  return (
    <div className="bg-[linear-gradient(195deg,#BD721A_-8.8%,#D5B440_15.87%,#C89039_32.9%)] flex p-[127px_0_107px_0] box-sizing-border">
      <img className="rounded-[90px] absolute left-[242.2px] top-[571px] w-[150.6px] h-[74px]" />
      <div className="relative flex flex-col w-[784.5px] h-[fit-content] box-sizing-border">
        <div className="m-[0_0_1px_0] flex flex-row justify-between self-end w-[609.7px] box-sizing-border">
          <div className="m-[10.3px_0_5.2px_0] flex flex-row justify-between w-[79.5px] h-[fit-content] box-sizing-border">
            <img className="m-[0_0_3.1px_0] w-[22.1px] h-[30.5px]" />
            <img className="w-[19.5px] h-[33.6px]" />
          </div>
          <div className="rounded-[40px] bg-[#CD9529] relative flex p-[6.9px_15.6px_12.9px_15.6px] w-[306px] h-[49px] box-sizing-border">
            <div className="flex w-[53px] h-[39px] box-sizing-border">
              <img className="w-[39.8px] h-[29.3px]" />
            </div>
          </div>
        </div>
        <div className="shadow-[inset_23.6px_-23.6px_23.6px_0px_rgba(165,165,165,0.1),inset_-23.6px_23.6px_23.6px_0px_rgba(255,255,255,0.1)] backdrop-blur-[23.6px] rounded-[55px] bg-[rgba(250,248,248,0.46)] relative m-[0_0_70px_0] flex self-start p-[133.5px_29px_102px_34px] box-sizing-border">
          <div className="relative flex flex-col box-sizing-border">
            <div className="m-[0_0_8.5px_0] inline-block self-start break-words font-['Poppins'] font-normal text-[24px] leading-[0.667] text-[#62360C]">
            EMAIL
            </div>
            <div className="bg-[#000000] m-[0_0_65.5px_0] w-[367px] h-[0px]">
            </div>
            <div className="m-[0_3px_9.5px_3px] inline-block self-start break-words font-['Poppins'] font-normal text-[24px] leading-[0.667] text-[#62360C]">
            Password
            </div>
            <div className="bg-[#000000] w-[367px] h-[0px]">
            </div>
          </div>
          <div className="absolute left-[34px] top-[40px] flex flex-col box-sizing-border">
            <div className="m-[0_0.1px_69px_0] inline-block self-center break-words font-['Poppins'] font-extrabold text-[40px] leading-[0.4] text-[#704A10]">
            Login
            </div>
            <div className="m-[0_0_34.5px_3.6px] flex flex-row justify-between w-[calc(100%_-_3.6px)] box-sizing-border">
              <div className="m-[3.5px_8px_3.5px_0] inline-block w-[236.3px] break-words">
              Username
              </div>
              <img className="w-[23.7px] h-[23px]" />
            </div>
            <div className="m-[0_4px_8.5px_4px] inline-block self-start break-words">
            EMAIL
            </div>
            <img className="m-[0_0_6.5px_0] self-end w-[23.7px] h-[27px]" />
            <span className="self-start break-words">
            Password
            </span>
          </div>
        </div>
        <div className="m-[0_507.4px_51px_0] inline-block self-center break-words font-['Poppins'] font-extrabold text-[32px] leading-[0.5] text-[#D6CCBD]">
        Login
        </div>
        <div className="relative m-[0_64.2px_24px_64.2px] flex self-start box-sizing-border">
          <span className="relative break-words font-['Poppins'] font-extrabold text-[20px] leading-[0.8] text-[#834C0D]">
          Forgot Password?
          </span>
          <div className="absolute left-[50%] bottom-[0px] translate-x-[-50%] flex box-sizing-border">
            <span className="break-words font-['Poppins'] font-extrabold text-[20px] underline leading-[0.8] text-[#834C0D]">
            Forgot Password?
            </span>
          </div>
        </div>
        <div className="m-[0_312.9px_0_0] flex self-center box-sizing-border">
          <span className="break-words font-['Poppins'] font-extrabold text-[20px] underline leading-[0.8] text-[#834C0D]">
          Create an account
          </span>
        </div>
      </div>
      <span className="absolute right-[188.8px] bottom-[94.8px] break-words font-['Poppins'] font-extrabold text-[20px] underline leading-[0.8] text-[#834C0D]">
      Create an account
      </span>
    </div>
  )
}