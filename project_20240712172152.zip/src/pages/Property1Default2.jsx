export default function Property1Default2() {
  return (
    <div className="box-sizing-border">
      <div className="rounded-[90px] border-[1px_solid_#000000] flex flex-row justify-between p-[17.9px_0_17.9px_0] w-[100%] h-[fit-content] box-sizing-border">
        <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
        Select
        </span>
        <div className="m-[8.5px_0_8.8px_0] flex w-[24px] h-[24px] box-sizing-border">
          <img className="w-[8.5px] h-[5.7px]" />
        </div>
      </div>
    </div>
  )
}