export default function MadpackersComByHtmlToDesignFreeVersion08072024233827Gmt530() {
  return (
    <div className="bg-[var(--madpackers-com-nero-athens-gray-background-image,linear-gradient(#F7F8F9,#F7F8F9))] bg-[var(--madpackers-com-nero-athens-gray-background-position-x,)_var(--madpackers-com-nero-athens-gray-background-position-y,)] bg-[length:var(--madpackers-com-nero-athens-gray-background-size,)] bg-var(--madpackers-com-nero-athens-gray-background-repeat, ) bg-var( bg-var( flex w-[1920px] box-sizing-border">
      <div className="relative flex flex-col items-center w-[1923px] h-[fit-content] box-sizing-border">
        <div className="m-[0_3px_64.8px_0] flex flex-col items-center w-[1914px] box-sizing-border">
          <div className="bg-[url('assets/images/Section.jpeg')] relative m-[0_2.7px_71.8px_3.3px] flex p-[250px_6.3px_10px_0] w-[1914px] box-sizing-border">
            <div className="opacity-40 bg-[var(--madpackers-com-black,#000000)] absolute left-[0px] top-[0px] right-[0px] bottom-[0px] h-[100%]">
            </div>
            <div className="absolute left-[0px] right-[0px] bottom-[-1px] h-[53px]">
              <img className="absolute top-[0px] right-[-525px] w-[2958.1px] h-[53px]" />
            </div>
            <div className="relative flex p-[0_0_7.5px_0] box-sizing-border">
              <div className="relative flex flex-col items-center box-sizing-border">
                <div className="m-[0_0px_12px_0] flex box-sizing-border">
                  <span className="shadow-[4px_2px_10px_0px_rgba(0,0,0,0.5)] text-center break-words font-['Poppins'] font-semibold text-[45px] leading-[1] text-[var(--madpackers-com-nero,#FFFFFF)]">
                  Experience the World,<br />
                  one bed at a time.
                  </span>
                </div>
                <div className="m-[0_0_28px_0] flex box-sizing-border">
                  <span className="shadow-[2px_1px_10px_0px_rgba(0,0,0,0.5)] text-center break-words font-['Lato'] font-normal text-[21px] leading-[1.19] text-[var(--madpackers-com-nero,#FFFFFF)]">
                  Tired of being tied down to expensive hotels during your<br />
                  travels in India? Our backpacker hostels provide the freedom<br />
                  and adventure you need.
                  </span>
                </div>
                <div className="relative m-[0_41px_0_41.3px] w-[563.7px] h-[156px]">
                  <div className="backdrop-blur-[9.5px] rounded-[24px] bg-[var(--madpackers-com-black-20,rgba(0,0,0,0.2))] absolute left-[50%] bottom-[0px] translate-x-[-50%] flex flex-col p-[32px_30px_22px_30px] box-sizing-border">
                    <div className="rounded-[22px] border-[2px_solid_var(--madpackers-com-black-30,rgba(0,0,0,0.3))] bg-[var(--madpackers-com-nero,#FFFFFF)] m-[0_0_8px_0] p-[19px_26px_19px_26px] w-[fit-content] box-sizing-border">
                      <span className="break-words font-['Poppins'] font-semibold text-[16px] leading-[1.438] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                      Where to next?
                      </span>
                    </div>
                    <div className="rounded-[22px] border-[1px_solid_var(--madpackers-com-jaffa,#F36E4F)] bg-[var(--madpackers-com-jaffa,#F36E4F)] flex p-[12px_0px_12px_0] w-[390px] box-sizing-border">
                      <span className="break-words font-['Poppins'] font-bold text-[16px] leading-[1.5] text-[var(--madpackers-com-nero,#FFFFFF)]">
                      BOOK NOW
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="absolute left-[50%] bottom-[0px] translate-x-[-50%] flex box-sizing-border">
                <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[18px] leading-[1] text-[var(--madpackers-com-wild-sand,#F5F5F5)]">
                
                </span>
              </div>
            </div>
          </div>
          <div className="bg-[var(--madpackers-com-wild-sand,#F5F5F5)] m-[0_3px_10px_3px] flex flex-col items-center p-[1px_0_55px_0] w-[1914px] box-sizing-border">
            <div className="m-[0_0px_16px_0] flex box-sizing-border">
              <span className="text-center break-words font-['Poppins'] font-semibold text-[38px] leading-[1] text-[var(--madpackers-com-jaffa,#F36E4F)]">
              Madpackers Hostels
              </span>
            </div>
            <div className="flex w-[1170px] box-sizing-border">
              <div className="flex flex-row w-[1110px] h-[fit-content] box-sizing-border">
                <div className="flex w-[222px] h-[291.4px] box-sizing-border">
                  <div className="bg-[url('assets/images/GoaPng.png')] w-[222px] h-[286.4px]">
                  </div>
                </div>
                <div className="flex w-[222px] h-[291.4px] box-sizing-border">
                  <div className="bg-[url('assets/images/MadpackersManaliHostelPng.png')] w-[222px] h-[286.4px]">
                  </div>
                </div>
                <div className="flex w-[222px] h-[291.4px] box-sizing-border">
                  <div className="bg-[url('assets/images/MadpackersAmritsarHostelPng.png')] w-[222px] h-[286.4px]">
                  </div>
                </div>
                <div className="flex w-[222px] h-[291.4px] box-sizing-border">
                  <div className="bg-[url('assets/images/JaipurPng.png')] w-[222px] h-[286.4px]">
                  </div>
                </div>
                <div className="flex w-[222px] h-[291.4px] box-sizing-border">
                  <div className="bg-[url('assets/images/MadpackersBirHostelPng.png')] w-[222px] h-[286.4px]">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="m-[0_0_55px_0] flex w-[1914px] h-[324.8px] box-sizing-border">
            <div className="rounded-[24px] bg-[url('assets/images/MadpackersNewInitiativeCreatorshipProgram1024X307Png.png')] w-[900px] h-[269.8px]">
            </div>
          </div>
          <div className="bg-[var(--madpackers-com-cod-gray-1,#141414)] m-[0_0_36px_0] flex flex-col items-center p-[75px_0_0_0] w-[1920px] box-sizing-border">
            <div className="m-[0_0_12px_0] flex box-sizing-border">
              <span className="text-center break-words font-['Poppins'] font-semibold text-[38px] leading-[1] text-[var(--madpackers-com-sea-buckthorn,#FCB32F)]">
              Featured On
              </span>
            </div>
            <div className="flex w-[1170px] h-[445.6px] box-sizing-border">
              <div className="bg-[url('assets/images/MadpackersFeaturedInPng.png')] w-[760.5px] h-[405.6px]">
              </div>
            </div>
          </div>
          <div className="m-[0_0_55px_0] flex flex-col items-center w-[fit-content] box-sizing-border">
            <div className="m-[0_0px_6px_0] flex box-sizing-border">
              <span className="text-center break-words font-['Poppins'] font-semibold text-[38px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
              Blog
              </span>
            </div>
            <div className="m-[0_0_45px_0] flex flex-col items-center w-[fit-content] box-sizing-border">
              <div className="m-[0_0_24.9px_0] flex flex-row gap-[0_30px] w-[fit-content] box-sizing-border">
                <div className="shadow-[0px_0px_10px_0px_rgba(0,0,0,0.15)] rounded-[18px] bg-[var(--madpackers-com-nero,#FFFFFF)] m-[0_0_10.1px_0] flex flex-col box-sizing-border">
                  <div className="bg-[url('assets/images/UdaipurToAhmedabadTrainJpg.jpeg')] relative m-[0_0_20px_0] w-[370px] h-[266.8px]">
                    <div className="bg-[var(--madpackers-com-linear-black-black-background-image,linear-gradient(0deg,rgba(0,0,0,0.35),rgba(0,0,0,0)))] bg-[var(--madpackers-com-linear-black-black-background-position-x,)_var(--madpackers-com-linear-black-black-background-position-y,)] bg-[length:var(--madpackers-com-linear-black-black-background-size,)] bg-var(--madpackers-com-linear-black-black-background-repeat, ) bg-var( bg-var( absolute left-[50%] bottom-[0px] translate-x-[-50%] w-[370px] h-[246.8px]">
                    </div>
                  </div>
                  <div className="m-[0_0_25px_11px] flex box-sizing-border">
                    <span className="break-words font-['Poppins'] font-medium text-[21px] leading-[1.19] text-[var(--madpackers-com-jaffa,#F36E4F)]">
                    Udaipur to Ahmedabad by Train:<br />
                    Tips, Tricks, and Timings
                    </span>
                  </div>
                  <div className="border-t-[1px_solid_var(--madpackers-com-mercury,#EAEAEA)] p-[10px_11px_10px_11px] w-[fit-content] box-sizing-border">
                    <span className="break-words font-['Roboto'] font-[var(--madpackers-com-roboto-regular-12-font-weight,400)] text-[12px] leading-[var(--madpackers-com-roboto-regular-12-line-height,1.3)] text-[var(--madpackers-com-boulder,#7A7A7A)]">
                    February 13, 2024
                    </span>
                  </div>
                </div>
                <div className="shadow-[0px_0px_10px_0px_rgba(0,0,0,0.15)] rounded-[18px] bg-[var(--madpackers-com-nero,#FFFFFF)] flex flex-col box-sizing-border">
                  <div className="bg-[url('assets/images/BestPlacesToTravelInIndiaInAprilJpg.jpeg')] relative m-[0_0_20px_0] w-[370px] h-[277px]">
                    <div className="bg-[var(--madpackers-com-linear-black-black-1-background-image,linear-gradient(0deg,rgba(0,0,0,0.35),rgba(0,0,0,0)))] bg-[var(--madpackers-com-linear-black-black-1-background-position-x,)_var(--madpackers-com-linear-black-black-1-background-position-y,)] bg-[length:var(--madpackers-com-linear-black-black-1-background-size,)] bg-var(--madpackers-com-linear-black-black-1-background-repeat, ) bg-var( bg-var( absolute left-[50%] bottom-[0px] translate-x-[-50%] w-[370px] h-[257px]">
                    </div>
                  </div>
                  <div className="m-[0_14.4px_25px_11px] flex box-sizing-border">
                    <span className="break-words font-['Poppins'] font-medium text-[21px] leading-[1.19] text-[var(--madpackers-com-jaffa,#F36E4F)]">
                    Where to Travel in India During<br />
                    April? Discover Top Destinations!
                    </span>
                  </div>
                  <div className="border-t-[1px_solid_var(--madpackers-com-mercury,#EAEAEA)] p-[10px_11px_10px_11px] w-[fit-content] box-sizing-border">
                    <span className="break-words font-['Roboto'] font-[var(--madpackers-com-roboto-regular-12-font-weight,400)] text-[12px] leading-[var(--madpackers-com-roboto-regular-12-line-height,1.3)] text-[var(--madpackers-com-boulder,#7A7A7A)]">
                    February 9, 2024
                    </span>
                  </div>
                </div>
                <div className="shadow-[0px_0px_10px_0px_rgba(0,0,0,0.15)] rounded-[18px] bg-[var(--madpackers-com-nero,#FFFFFF)] m-[0_0_9.6px_0] flex flex-col box-sizing-border">
                  <div className="bg-[url('assets/images/BestTimeToVisitKhajurahoJpg.jpeg')] relative m-[0_0_20px_0] w-[370px] h-[267.3px]">
                    <div className="bg-[var(--madpackers-com-linear-black-black-2-background-image,linear-gradient(0deg,rgba(0,0,0,0.35),rgba(0,0,0,0)))] bg-[var(--madpackers-com-linear-black-black-2-background-position-x,)_var(--madpackers-com-linear-black-black-2-background-position-y,)] bg-[length:var(--madpackers-com-linear-black-black-2-background-size,)] bg-var(--madpackers-com-linear-black-black-2-background-repeat, ) bg-var( bg-var( absolute left-[50%] bottom-[0px] translate-x-[-50%] w-[370px] h-[247.3px]">
                    </div>
                  </div>
                  <div className="m-[0_0_25px_11px] flex box-sizing-border">
                    <span className="break-words font-['Poppins'] font-medium text-[21px] leading-[1.19] text-[var(--madpackers-com-jaffa,#F36E4F)]">
                    Planning a Khajuraho Trip? Know<br />
                    When to Go!
                    </span>
                  </div>
                  <div className="border-t-[1px_solid_var(--madpackers-com-mercury,#EAEAEA)] p-[10px_11px_10px_11px] w-[fit-content] box-sizing-border">
                    <span className="break-words font-['Roboto'] font-[var(--madpackers-com-roboto-regular-12-font-weight,400)] text-[12px] leading-[var(--madpackers-com-roboto-regular-12-line-height,1.3)] text-[var(--madpackers-com-boulder,#7A7A7A)]">
                    February 6, 2024
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex flex-row gap-[0_30px] w-[fit-content] box-sizing-border">
                <div className="flex h-[399.7px] box-sizing-border">
                  <div className="shadow-[0px_0px_10px_0px_rgba(0,0,0,0.15)] rounded-[18px] bg-[var(--madpackers-com-nero,#FFFFFF)] relative flex h-[409.8px] box-sizing-border">
                    <div className="relative flex flex-col box-sizing-border">
                      <div className="bg-[url('assets/images/BestTimeToVisitGoaJpg.jpeg')] relative m-[0_0_20px_0] w-[370px] h-[298.3px]">
                        <div className="bg-[var(--madpackers-com-linear-black-black-3-background-image,linear-gradient(0deg,rgba(0,0,0,0.35),rgba(0,0,0,0)))] bg-[var(--madpackers-com-linear-black-black-3-background-position-x,)_var(--madpackers-com-linear-black-black-3-background-position-y,)] bg-[length:var(--madpackers-com-linear-black-black-3-background-size,)] bg-var(--madpackers-com-linear-black-black-3-background-repeat, ) bg-var( bg-var( absolute left-[50%] bottom-[0px] translate-x-[-50%] w-[370px] h-[278.3px]">
                        </div>
                      </div>
                      <div className="m-[0_11px_0_11px] flex self-start box-sizing-border">
                        <span className="break-words font-['Poppins'] font-medium text-[21px] leading-[1.19] text-[var(--madpackers-com-jaffa,#F36E4F)]">
                        When is the Best Time to Visit<br />
                        Goa?
                        </span>
                      </div>
                    </div>
                    <div className="border-t-[1px_solid_var(--madpackers-com-mercury,#EAEAEA)] absolute left-[50%] bottom-[-0.4px] translate-x-[-50%] p-[10px_11px_10px_11px] w-[370px] box-sizing-border">
                      <span className="break-words font-['Roboto'] font-[var(--madpackers-com-roboto-regular-12-font-weight,400)] text-[12px] leading-[var(--madpackers-com-roboto-regular-12-line-height,1.3)] text-[var(--madpackers-com-boulder,#7A7A7A)]">
                      February 3, 2024
                      </span>
                    </div>
                  </div>
                </div>
                <div className="shadow-[0px_0px_10px_0px_rgba(0,0,0,0.15)] rounded-[18px] bg-[var(--madpackers-com-nero,#FFFFFF)] relative m-[10.2px_0_31.1px_0] flex h-[368.5px] box-sizing-border">
                  <div className="relative flex flex-col items-center box-sizing-border">
                    <div className="bg-[url('assets/images/RishikeshToJoshimathBusTravelJpg.jpeg')] relative m-[0_0_20px_0] w-[370px] h-[231.9px]">
                      <div className="bg-[var(--madpackers-com-linear-black-black-4-background-image,linear-gradient(0deg,rgba(0,0,0,0.35),rgba(0,0,0,0)))] bg-[var(--madpackers-com-linear-black-black-4-background-position-x,)_var(--madpackers-com-linear-black-black-4-background-position-y,)] bg-[length:var(--madpackers-com-linear-black-black-4-background-size,)] bg-var(--madpackers-com-linear-black-black-4-background-repeat, ) bg-var( bg-var( absolute left-[50%] bottom-[0px] translate-x-[-50%] w-[370px] h-[211.9px]">
                      </div>
                    </div>
                    <div className="m-[0_4.2px_0_11px] flex box-sizing-border">
                      <span className="break-words font-['Poppins'] font-medium text-[21px] leading-[1.19] text-[var(--madpackers-com-jaffa,#F36E4F)]">
                      Rishikesh to Joshimath Bus<br />
                      Travel: A Complete Guide for the<br />
                      Himalayan Route
                      </span>
                    </div>
                  </div>
                  <div className="border-t-[1px_solid_var(--madpackers-com-mercury,#EAEAEA)] absolute left-[50%] bottom-[-0.4px] translate-x-[-50%] p-[10px_11px_10px_11px] w-[370px] box-sizing-border">
                    <span className="break-words font-['Roboto'] font-[var(--madpackers-com-roboto-regular-12-font-weight,400)] text-[12px] leading-[var(--madpackers-com-roboto-regular-12-line-height,1.3)] text-[var(--madpackers-com-boulder,#7A7A7A)]">
                    January 30, 2024
                    </span>
                  </div>
                </div>
                <div className="m-[0.5px_0_5.4px_0] flex box-sizing-border">
                  <div className="shadow-[0px_0px_10px_0px_rgba(0,0,0,0.15)] rounded-[18px] bg-[var(--madpackers-com-nero,#FFFFFF)] flex flex-col box-sizing-border">
                    <div className="bg-[url('assets/images/BestHimachalPradeshLocalFoodJpg.jpeg')] relative m-[0_0_20px_0] w-[370px] h-[267.3px]">
                      <div className="bg-[var(--madpackers-com-linear-black-black-2-background-image,linear-gradient(0deg,rgba(0,0,0,0.35),rgba(0,0,0,0)))] bg-[var(--madpackers-com-linear-black-black-2-background-position-x,)_var(--madpackers-com-linear-black-black-2-background-position-y,)] bg-[length:var(--madpackers-com-linear-black-black-2-background-size,)] bg-var(--madpackers-com-linear-black-black-2-background-repeat, ) bg-var( bg-var( absolute left-[50%] bottom-[0px] translate-x-[-50%] w-[370px] h-[247.3px]">
                      </div>
                    </div>
                    <div className="m-[0_11px_25px_11px] flex self-start box-sizing-border">
                      <span className="break-words font-['Poppins'] font-medium text-[21px] leading-[1.19] text-[var(--madpackers-com-jaffa,#F36E4F)]">
                      10 Must-Try Local Foods in<br />
                      Himachal Pradesh That Will<br />
                      Make Your Taste Buds Dance
                      </span>
                    </div>
                    <div className="border-t-[1px_solid_var(--madpackers-com-mercury,#EAEAEA)] p-[10px_11px_10px_11px] w-[fit-content] box-sizing-border">
                      <span className="break-words font-['Roboto'] font-[var(--madpackers-com-roboto-regular-12-font-weight,400)] text-[12px] leading-[var(--madpackers-com-roboto-regular-12-line-height,1.3)] text-[var(--madpackers-com-boulder,#7A7A7A)]">
                      January 23, 2024
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="m-[0_0px_0_0] flex w-[1170px] box-sizing-border">
              <div className="rounded-[24px] bg-[var(--madpackers-com-jaffa,#F36E4F)] flex p-[12px_0_12px_0] w-[121px] h-[fit-content] box-sizing-border">
                <span className="break-words font-['Roboto'] font-medium text-[15px] leading-[1] text-[var(--madpackers-com-nero,#FFFFFF)]">
                Read More
                </span>
              </div>
            </div>
          </div>
          <div className="bg-[var(--madpackers-com-tana,#DDD8C3)] m-[0_3px_75px_3px] flex flex-col items-center p-[42.5px_0_85px_0] w-[1914px] box-sizing-border">
            <div className="m-[0_0px_27.5px_0] flex box-sizing-border">
              <span className="text-center break-words font-['Poppins'] font-semibold text-[35px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
              Upcoming Destinations
              </span>
            </div>
            <div className="m-[0_0_45px_0] flex flex-col items-center w-[980px] box-sizing-border">
              <div className="m-[0_0_0px_0] flex flex-row w-[980px] box-sizing-border">
                <div className="flex w-[245px] h-[316.1px] box-sizing-border">
                  <div className="rounded-[24px] bg-[url('assets/images/BengaluruPng.png')] w-[245px] h-[316.1px]">
                  </div>
                </div>
                <div className="flex w-[245px] h-[316.1px] box-sizing-border">
                  <div className="rounded-[24px] bg-[url('assets/images/ShillongPng.png')] w-[245px] h-[316.1px]">
                  </div>
                </div>
                <div className="flex w-[245px] h-[316.1px] box-sizing-border">
                  <div className="rounded-[24px] bg-[url('assets/images/MukteshwarPng.png')] w-[245px] h-[316.1px]">
                  </div>
                </div>
                <div className="flex w-[245px] h-[316.1px] box-sizing-border">
                  <div className="rounded-[24px] bg-[url('assets/images/CoorgPng.png')] w-[245px] h-[316.1px]">
                  </div>
                </div>
              </div>
              <div className="flex flex-row w-[980px] box-sizing-border">
                <div className="flex w-[245px] h-[316.1px] box-sizing-border">
                  <div className="rounded-[24px] bg-[url('assets/images/NainitalPng.png')] w-[245px] h-[316.1px]">
                  </div>
                </div>
                <div className="flex w-[245px] h-[316.1px] box-sizing-border">
                  <div className="rounded-[24px] bg-[url('assets/images/KasarDeviPng.png')] w-[245px] h-[316.1px]">
                  </div>
                </div>
                <div className="flex w-[245px] h-[316.1px] box-sizing-border">
                  <div className="rounded-[24px] bg-[url('assets/images/JodhpurPng.png')] w-[245px] h-[316.1px]">
                  </div>
                </div>
                <div className="flex w-[245px] h-[316.1px] box-sizing-border">
                  <div className="rounded-[24px] bg-[url('assets/images/WayanadPng.png')] w-[245px] h-[316.1px]">
                  </div>
                </div>
              </div>
            </div>
            <div className="flex w-[980px] h-[372.5px] box-sizing-border">
              <div className="rounded-[12px] bg-[url('assets/images/MadpackersPaytmBus1024X384Jpg.jpeg')] w-[900px] h-[337.5px]">
              </div>
            </div>
          </div>
          <div className="m-[0_619.6px_0_0] flex flex-col w-[fit-content] box-sizing-border">
            <div className="m-[0_0_24.5px_0] flex self-start box-sizing-border">
              <span className="break-words font-['Poppins'] font-semibold text-[35px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
              FAQs
              </span>
            </div>
            <div className="m-[0_0_0_15px] flex flex-col w-[fit-content] box-sizing-border">
              <div className="m-[0_0_29.5px_0] flex flex-row self-start w-[fit-content] box-sizing-border">
                <div className="m-[0.5px_7.1px_0_0] flex box-sizing-border">
                  <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  
                  </span>
                </div>
                <div className="m-[0_0_0.5px_0] flex box-sizing-border">
                  <span className="break-words font-['Roboto'] font-bold text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  Do you offer any discounts for booking online or in advance?
                  </span>
                </div>
              </div>
              <div className="m-[0_0_29.5px_0] flex flex-row self-start w-[fit-content] box-sizing-border">
                <div className="m-[0.5px_7.1px_0_0] flex box-sizing-border">
                  <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  
                  </span>
                </div>
                <div className="m-[0_0_0.5px_0] flex box-sizing-border">
                  <span className="break-words font-['Roboto'] font-bold text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  Do you have any special policies for large groups or events?
                  </span>
                </div>
              </div>
              <div className="m-[0_0_29.5px_0] flex flex-row w-[fit-content] box-sizing-border">
                <div className="m-[0.5px_7.1px_0_0] flex box-sizing-border">
                  <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  
                  </span>
                </div>
                <div className="m-[0_0_0.5px_0] flex box-sizing-border">
                  <span className="break-words font-['Roboto'] font-bold text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  Do you have a loyalty program or rewards system for repeat guests?
                  </span>
                </div>
              </div>
              <div className="m-[0_0_29.5px_0] flex flex-row self-start w-[fit-content] box-sizing-border">
                <div className="m-[0.5px_7.1px_0_0] flex box-sizing-border">
                  <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  
                  </span>
                </div>
                <div className="m-[0_0_0.5px_0] flex box-sizing-border">
                  <span className="break-words font-['Roboto'] font-bold text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  Are the Madpackers Hostels located in safe areas?
                  </span>
                </div>
              </div>
              <div className="m-[0_43.5px_29.5px_0] flex flex-row w-[fit-content] box-sizing-border">
                <div className="m-[0.5px_7.1px_0_0] flex box-sizing-border">
                  <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  
                  </span>
                </div>
                <div className="m-[0_0_0.5px_0] flex box-sizing-border">
                  <span className="break-words font-['Roboto'] font-bold text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  Are there any additional fees or deposits required at check-in?
                  </span>
                </div>
              </div>
              <div className="m-[0_0_29.5px_0] flex flex-row self-start w-[fit-content] box-sizing-border">
                <div className="m-[0.5px_7.1px_0_0] flex box-sizing-border">
                  <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  
                  </span>
                </div>
                <div className="m-[0_0_0.5px_0] flex box-sizing-border">
                  <span className="break-words font-['Roboto'] font-bold text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  Do you have a guest computer or printer available for use?
                  </span>
                </div>
              </div>
              <div className="m-[0_0_29.5px_0] flex flex-row self-start w-[fit-content] box-sizing-border">
                <div className="m-[0.5px_7.1px_0_0] flex box-sizing-border">
                  <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  
                  </span>
                </div>
                <div className="m-[0_0_0.5px_0] flex box-sizing-border">
                  <span className="break-words font-['Roboto'] font-bold text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  Are there any age restrictions for guests?
                  </span>
                </div>
              </div>
              <div className="m-[0_0_29.5px_0] flex flex-row self-start w-[fit-content] box-sizing-border">
                <div className="m-[0.5px_7.1px_0_0] flex box-sizing-border">
                  <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  
                  </span>
                </div>
                <div className="m-[0_0_0.5px_0] flex box-sizing-border">
                  <span className="break-words font-['Roboto'] font-bold text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  Is there a common area for guests to use?
                  </span>
                </div>
              </div>
              <div className="m-[0_0_29.5px_0] flex flex-row self-start w-[fit-content] box-sizing-border">
                <div className="m-[0.5px_7.1px_0_0] flex box-sizing-border">
                  <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  
                  </span>
                </div>
                <div className="m-[0_0_0.5px_0] flex box-sizing-border">
                  <span className="break-words font-['Roboto'] font-bold text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  Is the hostel wheelchair accessible?
                  </span>
                </div>
              </div>
              <div className="m-[0_37.4px_29.5px_0] flex flex-row w-[fit-content] box-sizing-border">
                <div className="m-[0.5px_7.1px_0_0] flex box-sizing-border">
                  <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  
                  </span>
                </div>
                <div className="m-[0_0_0.5px_0] flex box-sizing-border">
                  <span className="break-words font-['Roboto'] font-bold text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  Do you have any recommendations for things to do in the area?
                  </span>
                </div>
              </div>
              <div className="m-[0_0_29.5px_0] flex flex-row self-start w-[fit-content] box-sizing-border">
                <div className="m-[0.5px_7.1px_0_0] flex box-sizing-border">
                  <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  
                  </span>
                </div>
                <div className="m-[0_0_0.5px_0] flex box-sizing-border">
                  <span className="break-words font-['Roboto'] font-bold text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  Can I bring my own towel or do you provide them?
                  </span>
                </div>
              </div>
              <div className="m-[0_0_29.5px_0] flex flex-row self-start w-[fit-content] box-sizing-border">
                <div className="m-[0.5px_7.1px_0_0] flex box-sizing-border">
                  <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  
                  </span>
                </div>
                <div className="m-[0_0_0.5px_0] flex box-sizing-border">
                  <span className="break-words font-['Roboto'] font-bold text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  Is there free WiFi available?
                  </span>
                </div>
              </div>
              <div className="m-[0_0.3px_29.5px_0] flex flex-row w-[fit-content] box-sizing-border">
                <div className="m-[0.5px_7.1px_0_0] flex box-sizing-border">
                  <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  
                  </span>
                </div>
                <div className="m-[0_0_0.5px_0] flex box-sizing-border">
                  <span className="break-words font-['Roboto'] font-bold text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  Do I need to bring a government-issued ID or passport for check-in?
                  </span>
                </div>
              </div>
              <div className="flex flex-row self-start w-[fit-content] box-sizing-border">
                <div className="m-[0.5px_7.1px_0_0] flex box-sizing-border">
                  <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  
                  </span>
                </div>
                <div className="m-[0_0_0.5px_0] flex box-sizing-border">
                  <span className="break-words font-['Roboto'] font-bold text-[17px] leading-[1] text-[var(--madpackers-com-mine-shaft-1,#222222)]">
                  What time is check-in and check-out?
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="m-[0_0_0_3px] flex flex-col items-center w-[1920px] box-sizing-border">
          <div className="bg-[var(--madpackers-com-cod-gray,#1A1A1A)] flex flex-row p-[50px_0_34px_0] w-[1920px] box-sizing-border">
            <div className="m-[0_64.3px_43px_0] flex flex-col box-sizing-border">
              <div className="m-[0_0_22px_0] flex self-start w-[277.5px] h-[45px] box-sizing-border">
                <div className="bg-[url('assets/images/MadpackersLogoPng.png')] w-[45px] h-[45px]">
                </div>
              </div>
              <div className="flex box-sizing-border">
                <span className="break-words font-['Roboto'] font-normal text-[16px] leading-[1.313] text-[var(--madpackers-com-wild-sand,#F5F5F5)]">
                Experience the joy of travel with<br />
                Madpackers, the go-to backpacker<br />
                hostel chain in India. Discover our<br />
                vibrant and welcoming hostels across<br />
                multiple locations, offering a unique<br />
                blend of adventure, culture, and<br />
                community.
                </span>
              </div>
            </div>
            <div className="m-[0_159.3px_0_0] flex flex-col box-sizing-border">
              <div className="m-[0_0_32px_0] flex self-start box-sizing-border">
                <span className="break-words font-['Poppins'] font-bold text-[24px] leading-[1] text-[var(--madpackers-com-jaffa,#F36E4F)]">
                Links
                </span>
              </div>
              <div className="m-[0_0_0_10px] flex flex-row w-[fit-content] box-sizing-border">
                <div className="m-[0_131.2px_0_0] flex flex-col box-sizing-border">
                  <div className="m-[0_0_24px_0] flex self-start box-sizing-border">
                    <span className="break-words font-['Roboto'] font-normal text-[16px] leading-[1.313] text-[var(--madpackers-com-nero,#FFFFFF)]">
                    Home
                    </span>
                  </div>
                  <div className="m-[0_0_24px_0] flex self-start box-sizing-border">
                    <span className="break-words font-['Roboto'] font-normal text-[16px] leading-[1.313] text-[var(--madpackers-com-nero,#FFFFFF)]">
                    About
                    </span>
                  </div>
                  <div className="m-[0_0_24px_0] flex self-start box-sizing-border">
                    <span className="break-words font-['Roboto'] font-normal text-[16px] leading-[1.313] text-[var(--madpackers-com-nero,#FFFFFF)]">
                    Contact
                    </span>
                  </div>
                  <div className="m-[0_7.8px_24px_0] flex box-sizing-border">
                    <span className="break-words font-['Roboto'] font-normal text-[16px] leading-[1.313] text-[var(--madpackers-com-nero,#FFFFFF)]">
                    Privacy Policy
                    </span>
                  </div>
                  <div className="flex box-sizing-border">
                    <span className="break-words font-['Roboto'] font-normal text-[16px] leading-[1.313] text-[var(--madpackers-com-nero,#FFFFFF)]">
                    Hostel Policies
                    </span>
                  </div>
                </div>
                <div className="m-[0_0_40.5px_0] flex flex-col box-sizing-border">
                  <div className="m-[0_0_25.5px_0] flex self-start box-sizing-border">
                    <span className="break-words font-['Roboto'] font-normal text-[17px] leading-[1.235] text-[var(--madpackers-com-nero,#FFFFFF)]">
                    Destinations
                    </span>
                  </div>
                  <div className="m-[0_0_25.5px_0] flex self-start box-sizing-border">
                    <span className="break-words font-['Roboto'] font-normal text-[17px] leading-[1.235] text-[var(--madpackers-com-nero,#FFFFFF)]">
                    Blog
                    </span>
                  </div>
                  <div className="m-[0_0_25.5px_0] flex self-start box-sizing-border">
                    <span className="break-words font-['Roboto'] font-normal text-[17px] leading-[1.235] text-[var(--madpackers-com-nero,#FFFFFF)]">
                    Creatorship
                    </span>
                  </div>
                  <div className="flex box-sizing-border">
                    <span className="break-words font-['Roboto'] font-normal text-[17px] leading-[1.235] text-[var(--madpackers-com-nero,#FFFFFF)]">
                    Terms &amp; Conditions
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative m-[10px_0_108.7px_0] flex p-[0_3.8px_0_3.8px] box-sizing-border">
              <div className="relative flex flex-col items-center box-sizing-border">
                <div className="m-[0_0_46.3px_0px] flex box-sizing-border">
                  <span className="text-center break-words font-['Roboto'] font-normal text-[14px] leading-[1.5] text-[var(--madpackers-com-tana,#DDD8C3)]">
                  Mobile App Launching Soon
                  </span>
                </div>
                <div className="flex flex-row gap-[0_15px] w-[fit-content] box-sizing-border">
                  <div className="rounded-[25px] bg-[var(--madpackers-com-jaffa,#F36E4F)] flex p-[12.5px_17.5px_12.5px_17.5px] box-sizing-border">
                    <span className="break-words font-['Font_Awesome_5_Brands','Roboto_Condensed'] font-normal text-[25px] leading-[1] text-[var(--madpackers-com-nero,#FFFFFF)]">
                    
                    </span>
                  </div>
                  <div className="rounded-[25px] bg-[var(--madpackers-com-jaffa,#F36E4F)] flex p-[12.5px_17.7px_12.5px_17.7px] box-sizing-border">
                    <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[25px] leading-[1] text-[var(--madpackers-com-nero,#FFFFFF)]">
                    
                    </span>
                  </div>
                  <div className="rounded-[25px] bg-[var(--madpackers-com-jaffa,#F36E4F)] flex p-[12.5px_17.5px_12.5px_17.5px] box-sizing-border">
                    <span className="break-words font-['Font_Awesome_5_Brands','Roboto_Condensed'] font-normal text-[25px] leading-[1] text-[var(--madpackers-com-nero,#FFFFFF)]">
                    
                    </span>
                  </div>
                  <div className="rounded-[25px] bg-[var(--madpackers-com-jaffa,#F36E4F)] flex p-[12.5px_17.5px_12.5px_17.5px] box-sizing-border">
                    <span className="break-words font-['Font_Awesome_5_Brands','Roboto_Condensed'] font-normal text-[25px] leading-[1] text-[var(--madpackers-com-nero,#FFFFFF)]">
                    
                    </span>
                  </div>
                </div>
              </div>
              <div className="absolute left-[50%] top-[27px] translate-x-[-50%] flex flex-row box-sizing-border">
                <div className="m-[0_6px_0_0] flex w-[126.3px] h-[41.3px] box-sizing-border">
                  <div className="bg-[url('assets/images/DownloadOnTheAppStorePng.png')] w-[123.3px] h-[41.3px]">
                  </div>
                </div>
                <div className="m-[0.7px_0_0.7px_0] flex w-[126.3px] h-[40px] box-sizing-border">
                  <div className="bg-[url('assets/images/GetItOnGooglePlayPng.png')] w-[123.3px] h-[40px]">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="bg-[var(--madpackers-com-cod-gray,#1A1A1A)] flex flex-row justify-between p-[34.5px_10px_9.8px_0] w-[1920px] box-sizing-border">
            <div className="m-[0_0_25.7px_0] flex flex-col items-center box-sizing-border">
              <span className="break-words font-['Roboto'] font-[var(--madpackers-com-roboto-regular-14-font-weight,400)] text-[14px] leading-[var(--madpackers-com-roboto-regular-14-line-height,1.5)] text-[var(--madpackers-com-wild-sand,#F5F5F5)]">
              Madpackers © 2024. All Rights Reserved .
              </span>
              <div className="m-[0_0_0_1.9px] flex flex-row w-[fit-content] box-sizing-border">
                <span className="m-[0_2px_0_0] break-words">
                Managed by 
                </span>
                <div className="flex box-sizing-border">
                  <span className="break-words">
                  Derivate X
                  </span>
                </div>
              </div>
            </div>
            <div className="relative m-[7.7px_0_0_0] flex p-[19px_14.9px_14px_14.9px] w-[60px] h-[60px] box-sizing-border">
              <div className="rounded-[60px] bg-[var(--madpackers-com-science-blue,#0066CC)] absolute right-[0px] bottom-[0px] w-[60px] h-[60px]">
              </div>
              <div className="shadow-[1px_1px_10px_-1px_#AAAAAA] rounded-[5px] bg-[var(--madpackers-com-nero,#FFFFFF)] absolute left-[0px] bottom-[0px] p-[13px_15px_13px_15px] w-[200px] box-sizing-border">
                <div className="relative flex flex-col box-sizing-border">
                  <div className="m-[0_0_3px_0] flex self-start box-sizing-border">
                    <span className="break-words font-['Roboto'] font-[var(--madpackers-com-roboto-regular-141,400)] text-[14px] text-[var(--madpackers-com-mine-shaft,#333333)]">
                    We&#39;re offline
                    </span>
                  </div>
                  <div className="flex box-sizing-border">
                    <span className="break-words font-['Roboto'] font-[var(--madpackers-com-roboto-regular-13,400)] text-[13px] text-[var(--madpackers-com-dove-gray,#666666)]">
                    Leave a message
                    </span>
                  </div>
                </div>
                <div className="shadow-[1px_-1px_4px_0px_#EEEEEE] rounded-tr-[3px] bg-[var(--madpackers-com-nero,#FFFFFF)] rotate-[45deg] absolute top-[50%] right-[-7.1px] translate-y-[-50%] w-[10px] h-[10px]">
                </div>
              </div>
              <div className="rounded-[60px] relative flex w-[54px] h-[54px] box-sizing-border">
                <img className="w-[30.2px] h-[27px]" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="backdrop-blur-[2.5px] bg-[var(--madpackers-com-linear-nero-black-background-image,linear-gradient(279.92deg,rgba(255,255,255,0)_100%,rgba(0,0,0,0.28)_200%))] bg-[var(--madpackers-com-linear-nero-black-background-position-x,)_var(--madpackers-com-linear-nero-black-background-position-y,)] bg-[length:var(--madpackers-com-linear-nero-black-background-size,)] bg-var(--madpackers-com-linear-nero-black-background-repeat, ) bg-var( bg-var( absolute top-[0.2px] right-[-6.3px] flex flex-row justify-between p-[15px_26px_15px_10px] w-[1920px] h-[90px] box-sizing-border">
        <div className="flex w-[640px] h-[80px] box-sizing-border">
          <div className="bg-[url('assets/images/MadpackersLogoPng.png')] w-[60px] h-[60px]">
          </div>
        </div>
        <div className="m-[22px_0_22px_0] flex flex-row justify-between w-[1280px] h-[fit-content] box-sizing-border">
          <div className="flex box-sizing-border">
            <span className="break-words font-['Roboto'] font-medium text-[16px] underline leading-[1] text-[var(--madpackers-com-sea-buckthorn,#FCB32F)]">
            Home
            </span>
          </div>
          <div className="flex flex-row justify-between w-[545px] box-sizing-border">
            <div className="flex box-sizing-border">
              <span className="break-words font-['Roboto'] font-medium text-[16px] leading-[1] text-[var(--madpackers-com-nero,#FFFFFF)]">
              About
              </span>
            </div>
            <div className="flex box-sizing-border">
              <span className="break-words font-['Roboto'] font-medium text-[16px] underline leading-[1] text-[var(--madpackers-com-nero,#FFFFFF)]">
              Forums
              </span>
            </div>
            <div className="flex flex-row box-sizing-border">
              <span className="m-[0_10.1px_0_0] break-words font-['Roboto'] font-medium text-[16px] leading-[1] text-[var(--madpackers-com-nero,#FFFFFF)]">
              Hostels
              </span>
              <div className="m-[1px_0_1px_0] flex box-sizing-border">
                <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[14px] leading-[1] text-[var(--madpackers-com-nero,#FFFFFF)]">
                
                </span>
              </div>
            </div>
            <div className="flex flex-row box-sizing-border">
              <span className="m-[0_10.7px_0_0] break-words font-['Roboto'] font-medium text-[16px] leading-[1] text-[var(--madpackers-com-nero,#FFFFFF)]">
              Blog
              </span>
              <div className="m-[1px_0_1px_0] flex box-sizing-border">
                <span className="break-words font-['Font_Awesome_5_Free','Roboto_Condensed'] font-black text-[14px] leading-[1] text-[var(--madpackers-com-nero,#FFFFFF)]">
                
                </span>
              </div>
            </div>
            <div className="flex box-sizing-border">
              <span className="break-words font-['Roboto'] font-medium text-[16px] leading-[1] text-[var(--madpackers-com-nero,#FFFFFF)]">
              Creatorship
              </span>
            </div>
            <div className="flex box-sizing-border">
              <span className="break-words font-['Roboto'] font-medium text-[16px] underline leading-[1] text-[var(--madpackers-com-nero,#FFFFFF)]">
              Contact
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}