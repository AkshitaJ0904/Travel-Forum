export default function Webpage1() {
  return (
    <div className="bg-[linear-gradient(195deg,#BD721A_-8.8%,#D5B440_15.87%,#C89039_32.9%)] flex p-[127px_10px_82px_0] w-[1280px] box-sizing-border">
      <img className="rounded-[90px] absolute top-[578px] right-[305px] w-[286px] h-[74px]" />
      <div className="relative flex flex-col items-center box-sizing-border">
        <div className="rounded-[40px] bg-[#CD9529] relative m-[0_58px_8px_58px] flex flex-row justify-between self-end p-[6.9px_15.6px_11px_0] w-[306px] box-sizing-border">
          <img className="m-[1.1px_0_0_0] w-[42px] h-[30px]" />
          <div className="m-[0_0_1.9px_0] flex w-[53px] h-[39px] box-sizing-border">
            <img className="w-[39.8px] h-[29.3px]" />
          </div>
        </div>
        <div className="m-[0_0_70px_0] flex flex-row w-[fit-content] box-sizing-border">
          <div className="shadow-[0px_45px_50px_0px_rgba(0,0,0,0.25)] rounded-[50px] bg-[url('assets/images/Image11.png')] bg-[50%_50%] bg-cover bg-no-repeat w-[377px] h-[353px]">
          </div>
          <div className="shadow-[inset_23.6px_-23.6px_23.6px_0px_rgba(165,165,165,0.1),inset_-23.6px_23.6px_23.6px_0px_rgba(255,255,255,0.1)] backdrop-blur-[23.6px] rounded-[55px] bg-[rgba(250,248,248,0.46)] relative flex p-[133.5px_29px_102px_34px] box-sizing-border">
            <div className="relative flex flex-col box-sizing-border">
              <div className="m-[0_0_8.5px_0] inline-block self-start break-words font-['Poppins'] font-normal text-[24px] leading-[0.667] text-[#62360C]">
              EMAIL
              </div>
              <div className="bg-[#000000] m-[0_0_65.5px_0] w-[372px] h-[0px]">
              </div>
              <div className="m-[0_3px_9.5px_3px] inline-block self-start break-words font-['Poppins'] font-normal text-[24px] leading-[0.667] text-[#62360C]">
              Password
              </div>
              <div className="bg-[#000000] w-[372px] h-[0px]">
              </div>
            </div>
            <div className="absolute left-[34px] top-[40px] flex flex-col box-sizing-border">
              <div className="m-[0_1px_69px_0] inline-block self-center break-words font-['Poppins'] font-extrabold text-[40px] leading-[0.4] text-[#704A10]">
              Login
              </div>
              <div className="m-[0_0_34.5px_4px] flex flex-row justify-between w-[355px] box-sizing-border">
                <div className="m-[3.5px_8px_3.5px_0] inline-block w-[239px] break-words">
                Username
                </div>
                <img className="w-[24px] h-[23px]" />
              </div>
              <div className="m-[0_4px_8.5px_4px] inline-block self-start break-words">
              EMAIL
              </div>
              <img className="m-[0_0_6.5px_0] self-end w-[24px] h-[27px]" />
              <span className="self-start break-words">
              Password
              </span>
            </div>
          </div>
        </div>
        <div className="m-[0_0_51px_387.6px] inline-block break-words font-['Poppins'] font-extrabold text-[32px] leading-[0.5] text-[#D6CCBD]">
        Login
        </div>
        <div className="relative m-[0_0_44px_370.2px] flex box-sizing-border">
          <span className="relative break-words font-['Poppins'] font-extrabold text-[20px] leading-[0.8] text-[#834C0D]">
          Forgot Password?
          </span>
          <div className="absolute left-[50%] bottom-[0px] translate-x-[-50%] flex box-sizing-border">
            <span className="break-words font-['Poppins'] font-extrabold text-[20px] underline leading-[0.8] text-[#834C0D]">
            Forgot Password?
            </span>
          </div>
        </div>
        <span className="m-[0_0_0_378.2px] break-words font-['Poppins'] font-extrabold text-[20px] underline leading-[0.8] text-[#834C0D]">
        Create an account
        </span>
      </div>
      <img className="absolute top-[135px] right-[420px] w-[37px] h-[33px]" />
    </div>
  )
}