export default function MacBookAir3() {
  return (
    <div className="bg-[#270707] flex p-[9px_0_0_8px] w-[1235px] box-sizing-border">
      <div className="absolute left-[7.8px] top-[9.3px] flex w-[24px] h-[24px] box-sizing-border">
        <img className="w-[8.5px] h-[5.7px]" />
      </div>
      <div className="bg-[linear-gradient(195deg,#D3B484_-5.6%,#92764D_-3.73%,#D3B753_7.53%,#DCB67C_32.9%)] relative flex flex-col p-[34px_33px_87px_29px] w-[1241px] h-[fit-content] box-sizing-border">
        <div className="rounded-[90px] border-b-[1px_solid_var(--community-withairbnb-com-alto,#DDDDDD)] bg-[var(--community-withairbnb-com-wild-sand,#F7F7F7)] m-[0_0_49px_0] flex flex-row p-[13.5px_0_13.5px_0] w-[1179px] box-sizing-border">
          <div className="relative m-[2px_27px_2px_0] flex w-[353px] h-[79px] box-sizing-border">
            <div className="relative p-[16.4px_13.4px_19.4px_13.4px] w-[338px] h-[48px] box-sizing-border">
              <span className="break-words font-['Inter'] font-[var(--community-withairbnb-com-inter-medium-1575,500)] text-[15.8px] text-[var(--colors-orange,#FF9500)]">
              Search<br />
              
              </span>
              <div className="shadow-[0px_0px_0px_1px_rgba(0,0,0,0.03),0px_2px_4px_0px_rgba(0,0,0,0.06)] rounded-[8px] border-[1px_solid_var(--community-withairbnb-com-tundora,#484848)] bg-[var(--community-withairbnb-com-wild-sand,#F7F7F7)] absolute left-[50%] top-[0px] translate-x-[-50%] p-[21.5px_0_5.5px_32px] w-[338px] h-[48px] box-sizing-border">
                <span className="break-words font-['Inter'] font-[var(--community-withairbnb-com-inter-medium-1575,500)] text-[15.8px] text-[var(--colors-orange,#FF9500)]">
                Search<br />
                
                </span>
              </div>
              <div className="relative flex w-[17px] h-[17px] box-sizing-border">
                <img className="w-[12.3px] h-[12.3px]" />
              </div>
            </div>
            <div className="rounded-[8px] absolute left-[0px] bottom-[10.5px] flex box-sizing-border">
              <span className="break-words font-['Inter'] font-[var(--community-withairbnb-com-inter-medium-155-font-weight,500)] text-[15.5px] leading-[var(--community-withairbnb-com-inter-medium-155-line-height,1.29)] text-[var(--community-withairbnb-com-tundora,#484848)]">
              Search
              </span>
            </div>
          </div>
          <div className="m-[0_47.2px_0_0] flex flex-row box-sizing-border">
            <div className="m-[0_12px_0_0] flex w-[98px] box-sizing-border">
              <div className="rounded-[8px] border-[2px_solid_var(--madpackers-com-mine-shaft,#333333)] bg-[var(--community-withairbnb-com-green,#FFB400)] flex p-[14px_0_14px_0] w-[86px] h-[fit-content] box-sizing-border">
                <span className="break-words font-['Inter'] font-medium text-[15.6px] leading-[1.28] text-[var(--madpackers-com-mine-shaft,#333333)]">
                Post
                </span>
              </div>
            </div>
            <div className="m-[3.5px_12px_3.5px_0] flex w-[57px] h-[79px] box-sizing-border">
              <div className="border-[1px_solid_var(--community-withairbnb-com-wild-sand,#F7F7F7)] bg-[var(--community-withairbnb-com-wild-sand,#F7F7F7)] flex p-[13.8px_13.7px_13.8px_13.8px] w-[45px] h-[45px] box-sizing-border">
                <img className="w-[15.5px] h-[15.5px]" />
              </div>
            </div>
            <div className="m-[6px_0_6px_0] flex box-sizing-border">
              <div className="rounded-[50px] border-[1px_solid_var(--community-withairbnb-com-green,#FFB400)] flex p-[7px_16.5px_8px_14.9px] box-sizing-border">
                <span className="break-words font-['Inter'] font-bold text-[13.7px] underline leading-[1.682] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
                Log In
                </span>
              </div>
            </div>
          </div>
          <div className="relative m-[2.5px_0_2.5px_0] flex p-[14px_0_20.3px_134.6px] w-[213px] h-[266px] box-sizing-border">
            <span className="absolute left-[50%] top-[10px] translate-x-[-50%] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
            Travel Search 
            </span>
            <div className="rounded-[90px] border-[1px_solid_#000000] absolute left-[50%] top-[0px] translate-x-[-50%] w-[213px] h-[47px]">
              <span className="absolute left-[50%] top-[10px] translate-x-[-50%] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
              Travel Search 
              </span>
            </div>
            <img className="relative w-[15.6px] h-[12.8px]" />
          </div>
        </div>
        <div className="relative m-[0_19px_21px_19px] flex self-start box-sizing-border">
          <span className="relative break-words font-['Inter'] font-normal text-[23px] leading-[1.565] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
          Let’s talk
          </span>
          <div className="absolute left-[50%] bottom-[0px] translate-x-[-50%] flex box-sizing-border">
            <span className="break-words font-['Inter'] font-normal text-[23px] leading-[1.565] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
            Let’s talk
            </span>
          </div>
        </div>
        <div className="rounded-[90px] m-[0_16px_24.6px_16px] self-start box-sizing-border">
          <div className="shadow-[inset_0px_1px_1px_1px_rgba(0,0,0,0.075),0px_0px_8px_0px_rgba(0,0,0,0.6)] rounded-[12px] border-[1px_solid_var(--community-withairbnb-com-black,#000000)] bg-[var(--community-withairbnb-com-nero,#FFFFFF)] p-[26px_24px_27.4px_24px] box-sizing-border">
            <span className="break-words font-['Inter'] font-[var(--community-withairbnb-com-inter-light-1758,300)] text-[17.6px] text-[var(--community-withairbnb-com-silver-chalice,#A9A9A9)]">
            Enter a subject
            </span>
          </div>
        </div>
        <div className="relative m-[0_12px_46px_12px] flex self-start p-[0_0_263px_0] w-[1029px] box-sizing-border">
          <div className="bg-[var(--community-withairbnb-com-nero,#FFFFFF)] relative flex flex-row justify-between p-[11px_0_20.3px_16px] w-[1029px] h-[fit-content] box-sizing-border">
            <div className="rounded-[2px] m-[3px_0_1.7px_0] flex w-[40px] h-[36px] box-sizing-border">
              <img className="w-[8px] h-[12px]" />
            </div>
            <div className="rounded-[2px] m-[3px_0_1.7px_0] flex w-[40px] h-[36px] box-sizing-border">
              <img className="w-[11px] h-[12px]" />
            </div>
            <div className="rounded-[2px] m-[3px_0_1.7px_0] flex w-[40px] h-[36px] box-sizing-border">
              <img className="w-[9px] h-[12px]" />
            </div>
            <div className="rounded-[2px] flex w-[40px] h-[36px] box-sizing-border">
              <img className="w-[19.3px] h-[16.7px]" />
            </div>
            <div className="m-[2px_0_0.7px_0] flex flex-row w-[69px] h-[fit-content] box-sizing-border">
              <div className="rounded-[2px] m-[0_18px_0_0] flex flex-row w-[54px] box-sizing-border">
                <div className="m-[0_16px_0_0] flex w-[16px] h-[16px] box-sizing-border">
                  <img className="w-[13px] h-[14px]" />
                </div>
                <div className="border-l-[4px_solid_#747474] border-t-[4px_solid_#747474] border-r-[4px_solid_#747474] m-[5px_0_5px_0] w-[8px] h-[4px]">
                </div>
              </div>
              <div className="rounded-[2px] flex w-[40px] h-[36px] box-sizing-border">
                <img className="w-[14px] h-[14px]" />
              </div>
            </div>
          </div>
          <div className="shadow-[inset_0px_1px_1px_1px_rgba(0,0,0,0.075)] rounded-[12px] border-[1px_solid_var(--community-withairbnb-com-gray-nurse,#DFE0DF)] bg-[var(--community-withairbnb-com-nero,#FFFFFF)] absolute left-[0px] bottom-[0px] flex p-[0_0_12px_0] w-[1023px] h-[264px] box-sizing-border">
            <div className="rounded-[8px] border-[1px_solid_#000000] flex w-[1022px] h-[250px] box-sizing-border">
              <div className="rounded-[12px] bg-[var(--community-withairbnb-com-nero,#FFFFFF)] w-[1022px] h-[250px]">
              </div>
            </div>
          </div>
          <div className="absolute right-[1px] bottom-[4px] flex w-[1029px] h-[1px] box-sizing-border">
            <img className="w-[9px] h-[9px]" />
          </div>
        </div>
        <div className="m-[0_19px_15px_19px] flex self-start box-sizing-border">
          <span className="break-words font-['Inter'] font-normal text-[23px] leading-[1.565] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
          Choose a Topic
          </span>
        </div>
        <div className="m-[0_13px_70px_6px] flex flex-row w-[fit-content] box-sizing-border">
          <div className="bg-[#FFB400] relative m-[0_31px_1px_0] flex p-[11.5px_0_11.5px_7.7px] w-[247px] h-[fit-content] box-sizing-border">
            <span className="break-words font-['Inter'] font-normal text-[23px] leading-[1.565] text-[#000000]">
            Hostel Stays
            </span>
          </div>
          <div className="bg-[#D9D9D9] relative m-[0_47px_1px_0] flex p-[15.5px_13.5px_7.5px_0] w-[240px] h-[fit-content] box-sizing-border">
            <span className="break-words font-['Inter'] font-normal text-[23px] leading-[1.565] text-[#000000]">
            Travel Tips
            </span>
          </div>
          <div className="bg-[#D9D9D9] relative m-[1px_27px_0_0] flex p-[15px_2.3px_8px_0] w-[282px] h-[fit-content] box-sizing-border">
            <span className="break-words font-['Inter'] font-normal text-[23px] leading-[1.565] text-[#000000]">
            General Discussions
            </span>
          </div>
          <div className="bg-[#D9D9D9] relative m-[1px_0_0_0] flex p-[12px_24.6px_11px_27px] box-sizing-border">
            <span className="break-words font-['Inter'] font-normal text-[23px] leading-[1.565] text-[#000000]">
            Location Suggestions
            </span>
          </div>
        </div>
        <div className="m-[0_19px_28px_19px] flex self-start box-sizing-border">
          <span className="break-words font-['Inter'] font-normal text-[23px] leading-[1.565] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
          Choose a Location
          </span>
        </div>
        <div className="m-[0_41px_649px_41px] flex self-start w-[167px] box-sizing-border">
          <div className="rounded-[90px] border-[1px_solid_#000000] flex flex-row p-[17px_0_17px_0] w-[143.4px] h-[fit-content] box-sizing-border">
            <span className="m-[0_15.9px_0_0] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
            Select
            </span>
            <div className="m-[8.5px_0_8.8px_0] flex w-[24px] h-[24px] box-sizing-border">
              <img className="w-[8.5px] h-[5.7px]" />
            </div>
          </div>
        </div>
        <div className="bg-[#978B8B] m-[0_4px_32px_6px] w-[1169px] h-[0px]">
        </div>
        <div className="m-[0_62px_0_0] flex flex-row justify-between self-center w-[847px] box-sizing-border">
          <div className="rounded-[8px] border-[2px_solid_var(--madpackers-com-mine-shaft,#333333)] bg-[var(--community-withairbnb-com-alto,#DDDDDD)] flex p-[14px_0_14px_0] w-[230px] box-sizing-border">
            <span className="break-words font-['Inter'] font-medium text-[20px] leading-[1] text-[var(--madpackers-com-mine-shaft,#333333)]">
            Cancel
            </span>
          </div>
          <div className="rounded-[8px] border-[2px_solid_var(--madpackers-com-mine-shaft,#333333)] bg-[var(--community-withairbnb-com-green,#FFB400)] flex p-[14px_0_14px_0] w-[230px] box-sizing-border">
            <span className="break-words font-['Inter'] font-medium text-[20px] leading-[1] text-[var(--madpackers-com-mine-shaft,#333333)]">
            Post
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}