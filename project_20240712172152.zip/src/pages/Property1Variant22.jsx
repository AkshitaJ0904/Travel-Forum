export default function Property1Variant22() {
  return (
    <div className="flex flex-col box-sizing-border">
      <div className="rounded-[90px] border-[1px_solid_#000000] m-[0_6.8px_4px_0] flex flex-row justify-between p-[17px_0_17px_0] w-[calc(100%_-_6.8px)] box-sizing-border">
        <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
        Select
        </span>
        <div className="m-[8.5px_0_8.8px_0] flex w-[24px] h-[24px] box-sizing-border">
          <img className="w-[8.5px] h-[5.7px]" />
        </div>
      </div>
      <div className="rounded-[20px] border-[1px_solid_#000000] flex flex-col p-[17px_0_17px_16.7px] w-[100%] box-sizing-border">
        <div className="rounded-[90px] m-[0_0_36.5px_0] flex self-start box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Rishikesh
          </span>
        </div>
        <div className="rounded-[90px] m-[0_0_36.5px_0] flex self-center box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Goa
          </span>
        </div>
        <div className="rounded-[90px] m-[0_0_36px_0] flex self-center box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Manali
          </span>
        </div>
        <div className="rounded-[90px] m-[0_3.8px_36px_3.8px] flex self-start box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Amritsar
          </span>
        </div>
        <div className="rounded-[90px] m-[0_0_36px_0] flex self-center box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Jaipur
          </span>
        </div>
        <div className="rounded-[90px] m-[0_0_36px_0] flex self-center box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Bir
          </span>
        </div>
        <div className="rounded-[90px] m-[0_6.1px_36px_6.1px] flex self-start box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Udaipur
          </span>
        </div>
        <div className="rounded-[90px] m-[0_0_36px_0] flex self-center box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          jibhi
          </span>
        </div>
        <div className="rounded-[90px] m-[0_5.3px_36px_5.3px] flex self-start box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Pushkar
          </span>
        </div>
        <div className="rounded-[90px] m-[0_2.5px_0_2.5px] flex self-start box-sizing-border">
          <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[#0C0C0C]">
          Khajurao
          </span>
        </div>
      </div>
    </div>
  )
}