export default function Property1Default() {
  return (
    <div className="bg-[var(--bg-for-drop-down-background-image,linear-gradient(180deg,#DA914D,#D9A651,#D9DB5C))] bg-[var(--bg-for-drop-down-background-position-x,)_var(--bg-for-drop-down-background-position-y,)] bg-[length:var(--bg-for-drop-down-background-size,)] bg-var(--bg-for-drop-down-background-repeat, ) bg-var( bg-var( flex p-[15.3px_0_0_0] box-sizing-border">
      <div className="absolute right-[77.9px] bottom-[31px] flex w-[19px] h-[15px] box-sizing-border">
        <img className="w-[11.3px] h-[5.4px]" />
      </div>
      <div className="relative flex flex-col w-[100%] h-[fit-content] box-sizing-border">
        <div className="relative m-[0_0_1px_0] w-[100%] box-sizing-border">
          <div className="border-[1px_solid_var(--madpackers-com-mine-shaft,#333333)] relative flex p-[12px_0_12px_0] w-[100%] h-[fit-content] box-sizing-border">
            <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
             Hostel stays
            </span>
          </div>
          <span className="absolute left-[24.5px] bottom-[12.3px] break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
          Travel Search
          </span>
        </div>
        <div className="rounded-[90px] relative w-[220px] h-[57.7px]">
          <div className="absolute left-[0px] top-[0px] right-[0px] box-sizing-border">
            <div className="border-[1px_solid_var(--madpackers-com-mine-shaft,#333333)] flex p-[12px_0_12px_0] w-[100%] h-[fit-content] box-sizing-border">
              <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
              General Discussion
              </span>
            </div>
          </div>
          <div className="border-[1px_solid_var(--madpackers-com-mine-shaft,#333333)] absolute left-[0px] top-[50%] right-[0px] translate-y-[-50%] flex p-[12px_0_12px_0] box-sizing-border">
            <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
            Travel Tips
            </span>
          </div>
          <div className="border-[1px_solid_var(--madpackers-com-mine-shaft,#333333)] absolute left-[0px] right-[0px] bottom-[0px] flex p-[12px_0_12px_0] box-sizing-border">
            <span className="break-words font-['Inter'] font-medium text-[16px] leading-[1.438] text-[var(--community-withairbnb-com-mine-shaft-1,#222222)]">
            Location  Suggestions
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}