import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import './index.css';
import F12Main from './F12Main';

import CommunityWithairbnbComByHtmlToDesignFreeVersion10072024143825Gmt530 from './pages/CommunityWithairbnbComByHtmlToDesignFreeVersion10072024143825Gmt530';
import Frame22 from './pages/Frame22';
import Frame24 from './pages/Frame24';
import Frame25 from './pages/Frame25';
import Frame26 from './pages/Frame26';
import Frame27 from './pages/Frame27';
import Frame28 from './pages/Frame28';
import Frame29 from './pages/Frame29';
import Frame30 from './pages/Frame30';
import Frame31 from './pages/Frame31';
import Frame32 from './pages/Frame32';
import Frame33 from './pages/Frame33';
import Frame34 from './pages/Frame34';
import Frame35 from './pages/Frame35';
import Frame9 from './pages/Frame9';
import MacBookAir1 from './pages/MacBookAir1';
import MacBookAir3 from './pages/MacBookAir3';
import MacBookAir4 from './pages/MacBookAir4';
import MacBookAir5 from './pages/MacBookAir5';
import MacBookAir6 from './pages/MacBookAir6';
import MacBookAir7 from './pages/MacBookAir7';
import MacBookAir8 from './pages/MacBookAir8';
import MadpackersComByHtmlToDesignFreeVersion08072024233827Gmt530 from './pages/MadpackersComByHtmlToDesignFreeVersion08072024233827Gmt530';
import Property1Default from './pages/Property1Default';
import Property1Default1 from './pages/Property1Default1';
import Property1Default2 from './pages/Property1Default2';
import Property1Variant10 from './pages/Property1Variant10';
import Property1Variant11 from './pages/Property1Variant11';
import Property1Variant12 from './pages/Property1Variant12';
import Property1Variant13 from './pages/Property1Variant13';
import Property1Variant2 from './pages/Property1Variant2';
import Property1Variant21 from './pages/Property1Variant21';
import Property1Variant22 from './pages/Property1Variant22';
import Property1Variant3 from './pages/Property1Variant3';
import Property1Variant31 from './pages/Property1Variant31';
import Property1Variant32 from './pages/Property1Variant32';
import Property1Variant4 from './pages/Property1Variant4';
import Property1Variant41 from './pages/Property1Variant41';
import Property1Variant5 from './pages/Property1Variant5';
import Property1Variant51 from './pages/Property1Variant51';
import Property1Variant52 from './pages/Property1Variant52';
import Property1Variant6 from './pages/Property1Variant6';
import Property1Variant61 from './pages/Property1Variant61';
import Property1Variant62 from './pages/Property1Variant62';
import Property1Variant7 from './pages/Property1Variant7';
import Property1Variant71 from './pages/Property1Variant71';
import Property1Variant8 from './pages/Property1Variant8';
import Property1Variant9 from './pages/Property1Variant9';
import SelectorMain from './pages/SelectorMain';
import Webpage from './pages/Webpage';
import Webpage1 from './pages/Webpage1';
import Webpage2 from './pages/Webpage2';


const router = createBrowserRouter([
  { path: '/', element: <F12Main /> },
{ path: '/CommunityWithairbnbComByHtmlToDesignFreeVersion10072024143825Gmt530', element: <CommunityWithairbnbComByHtmlToDesignFreeVersion10072024143825Gmt530 /> },
{ path: '/Frame22', element: <Frame22 /> },
{ path: '/Frame24', element: <Frame24 /> },
{ path: '/Frame25', element: <Frame25 /> },
{ path: '/Frame26', element: <Frame26 /> },
{ path: '/Frame27', element: <Frame27 /> },
{ path: '/Frame28', element: <Frame28 /> },
{ path: '/Frame29', element: <Frame29 /> },
{ path: '/Frame30', element: <Frame30 /> },
{ path: '/Frame31', element: <Frame31 /> },
{ path: '/Frame32', element: <Frame32 /> },
{ path: '/Frame33', element: <Frame33 /> },
{ path: '/Frame34', element: <Frame34 /> },
{ path: '/Frame35', element: <Frame35 /> },
{ path: '/Frame9', element: <Frame9 /> },
{ path: '/MacBookAir1', element: <MacBookAir1 /> },
{ path: '/MacBookAir3', element: <MacBookAir3 /> },
{ path: '/MacBookAir4', element: <MacBookAir4 /> },
{ path: '/MacBookAir5', element: <MacBookAir5 /> },
{ path: '/MacBookAir6', element: <MacBookAir6 /> },
{ path: '/MacBookAir7', element: <MacBookAir7 /> },
{ path: '/MacBookAir8', element: <MacBookAir8 /> },
{ path: '/MadpackersComByHtmlToDesignFreeVersion08072024233827Gmt530', element: <MadpackersComByHtmlToDesignFreeVersion08072024233827Gmt530 /> },
{ path: '/Property1Default', element: <Property1Default /> },
{ path: '/Property1Default1', element: <Property1Default1 /> },
{ path: '/Property1Default2', element: <Property1Default2 /> },
{ path: '/Property1Variant10', element: <Property1Variant10 /> },
{ path: '/Property1Variant11', element: <Property1Variant11 /> },
{ path: '/Property1Variant12', element: <Property1Variant12 /> },
{ path: '/Property1Variant13', element: <Property1Variant13 /> },
{ path: '/Property1Variant2', element: <Property1Variant2 /> },
{ path: '/Property1Variant21', element: <Property1Variant21 /> },
{ path: '/Property1Variant22', element: <Property1Variant22 /> },
{ path: '/Property1Variant3', element: <Property1Variant3 /> },
{ path: '/Property1Variant31', element: <Property1Variant31 /> },
{ path: '/Property1Variant32', element: <Property1Variant32 /> },
{ path: '/Property1Variant4', element: <Property1Variant4 /> },
{ path: '/Property1Variant41', element: <Property1Variant41 /> },
{ path: '/Property1Variant5', element: <Property1Variant5 /> },
{ path: '/Property1Variant51', element: <Property1Variant51 /> },
{ path: '/Property1Variant52', element: <Property1Variant52 /> },
{ path: '/Property1Variant6', element: <Property1Variant6 /> },
{ path: '/Property1Variant61', element: <Property1Variant61 /> },
{ path: '/Property1Variant62', element: <Property1Variant62 /> },
{ path: '/Property1Variant7', element: <Property1Variant7 /> },
{ path: '/Property1Variant71', element: <Property1Variant71 /> },
{ path: '/Property1Variant8', element: <Property1Variant8 /> },
{ path: '/Property1Variant9', element: <Property1Variant9 /> },
{ path: '/SelectorMain', element: <SelectorMain /> },
{ path: '/Webpage', element: <Webpage /> },
{ path: '/Webpage1', element: <Webpage1 /> },
{ path: '/Webpage2', element: <Webpage2 /> },
]);

export default function App() {
  return (
    <RouterProvider router={router} />
  );
}