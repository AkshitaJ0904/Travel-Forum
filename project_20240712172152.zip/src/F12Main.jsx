const tableHeaderStyle = {
  backgroundColor: "#f2f2f2",
  padding: 8,
  border: "1px solid #ddd",
}

const tableCellStyle = {
  padding: 8,
  border: "1px solid #ddd",
  color: "blue",
}

export default function F12Main() {
  return (
    <div style={{ padding: 20 }}>
      <h1 style={{ marginBottom: 20, fontSize: 20 }}>Page List</h1>
      <table style={{ borderCollapse: 'collapse', border: '1px solid #ddd' }}>
        <thead>
          <tr>
            <th style={tableHeaderStyle}>URL</th>
            <th style={tableHeaderStyle}>Page</th>
          </tr>
        </thead>
        <tbody>
<tr>
            <td style={tableCellStyle}><a href='/CommunityWithairbnbComByHtmlToDesignFreeVersion10072024143825Gmt530'>/CommunityWithairbnbComByHtmlToDesignFreeVersion10072024143825Gmt530</a></td>
            <td style={tableCellStyle}><a href='/CommunityWithairbnbComByHtmlToDesignFreeVersion10072024143825Gmt530'>community.withairbnb.com by html.to.design ❤️ FREE version - 10/07/2024, 14:38:25 GMT+5:30</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame22'>/Frame22</a></td>
            <td style={tableCellStyle}><a href='/Frame22'>Frame 22</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame24'>/Frame24</a></td>
            <td style={tableCellStyle}><a href='/Frame24'>Frame 24</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame25'>/Frame25</a></td>
            <td style={tableCellStyle}><a href='/Frame25'>Frame 25</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame26'>/Frame26</a></td>
            <td style={tableCellStyle}><a href='/Frame26'>Frame 26</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame27'>/Frame27</a></td>
            <td style={tableCellStyle}><a href='/Frame27'>Frame 27</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame28'>/Frame28</a></td>
            <td style={tableCellStyle}><a href='/Frame28'>Frame 28</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame29'>/Frame29</a></td>
            <td style={tableCellStyle}><a href='/Frame29'>Frame 29</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame30'>/Frame30</a></td>
            <td style={tableCellStyle}><a href='/Frame30'>Frame 30</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame31'>/Frame31</a></td>
            <td style={tableCellStyle}><a href='/Frame31'>Frame 31</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame32'>/Frame32</a></td>
            <td style={tableCellStyle}><a href='/Frame32'>Frame 32</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame33'>/Frame33</a></td>
            <td style={tableCellStyle}><a href='/Frame33'>Frame 33</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame34'>/Frame34</a></td>
            <td style={tableCellStyle}><a href='/Frame34'>Frame 34</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame35'>/Frame35</a></td>
            <td style={tableCellStyle}><a href='/Frame35'>Frame 35</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame9'>/Frame9</a></td>
            <td style={tableCellStyle}><a href='/Frame9'>Frame 9</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/MacBookAir1'>/MacBookAir1</a></td>
            <td style={tableCellStyle}><a href='/MacBookAir1'>MacBook Air - 1</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/MacBookAir3'>/MacBookAir3</a></td>
            <td style={tableCellStyle}><a href='/MacBookAir3'>MacBook Air - 3</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/MacBookAir4'>/MacBookAir4</a></td>
            <td style={tableCellStyle}><a href='/MacBookAir4'>MacBook Air - 4</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/MacBookAir5'>/MacBookAir5</a></td>
            <td style={tableCellStyle}><a href='/MacBookAir5'>MacBook Air - 5</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/MacBookAir6'>/MacBookAir6</a></td>
            <td style={tableCellStyle}><a href='/MacBookAir6'>MacBook Air - 6</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/MacBookAir7'>/MacBookAir7</a></td>
            <td style={tableCellStyle}><a href='/MacBookAir7'>MacBook Air - 7</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/MacBookAir8'>/MacBookAir8</a></td>
            <td style={tableCellStyle}><a href='/MacBookAir8'>MacBook Air - 8</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/MadpackersComByHtmlToDesignFreeVersion08072024233827Gmt530'>/MadpackersComByHtmlToDesignFreeVersion08072024233827Gmt530</a></td>
            <td style={tableCellStyle}><a href='/MadpackersComByHtmlToDesignFreeVersion08072024233827Gmt530'>madpackers.com by html.to.design ❤️ FREE version - 08/07/2024, 23:38:27 GMT+5:30</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Default'>/Property1Default</a></td>
            <td style={tableCellStyle}><a href='/Property1Default'>Property 1=Default</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Default1'>/Property1Default1</a></td>
            <td style={tableCellStyle}><a href='/Property1Default1'>Property 1=Default</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Default2'>/Property1Default2</a></td>
            <td style={tableCellStyle}><a href='/Property1Default2'>Property 1=Default</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant10'>/Property1Variant10</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant10'>Property 1=Variant10</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant11'>/Property1Variant11</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant11'>Property 1=Variant11</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant12'>/Property1Variant12</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant12'>Property 1=Variant12</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant13'>/Property1Variant13</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant13'>Property 1=Variant13</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant2'>/Property1Variant2</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant2'>Property 1=Variant2</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant21'>/Property1Variant21</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant21'>Property 1=Variant2</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant22'>/Property1Variant22</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant22'>Property 1=Variant2</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant3'>/Property1Variant3</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant3'>Property 1=Variant3</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant31'>/Property1Variant31</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant31'>Property 1=Variant3</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant32'>/Property1Variant32</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant32'>Property 1=Variant3</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant4'>/Property1Variant4</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant4'>Property 1=Variant4</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant41'>/Property1Variant41</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant41'>Property 1=Variant4</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant5'>/Property1Variant5</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant5'>Property 1=Variant5</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant51'>/Property1Variant51</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant51'>Property 1=Variant5</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant52'>/Property1Variant52</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant52'>Property 1=Variant5</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant6'>/Property1Variant6</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant6'>Property 1=Variant6</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant61'>/Property1Variant61</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant61'>Property 1=Variant6</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant62'>/Property1Variant62</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant62'>Property 1=Variant6</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant7'>/Property1Variant7</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant7'>Property 1=Variant7</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant71'>/Property1Variant71</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant71'>Property 1=Variant7</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant8'>/Property1Variant8</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant8'>Property 1=Variant8</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant9'>/Property1Variant9</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant9'>Property 1=Variant9</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/SelectorMain'>/SelectorMain</a></td>
            <td style={tableCellStyle}><a href='/SelectorMain'>Selector main</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Webpage'>/Webpage</a></td>
            <td style={tableCellStyle}><a href='/Webpage'>webpage</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Webpage1'>/Webpage1</a></td>
            <td style={tableCellStyle}><a href='/Webpage1'>webpage</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Webpage2'>/Webpage2</a></td>
            <td style={tableCellStyle}><a href='/Webpage2'>webpage 2</a></td>
          </tr>
</tbody>
      </table>
    </div>
  );
}